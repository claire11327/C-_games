﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = 1;
            int rowlen;
            int collen;
            int r, c;
            Console.Write("請輸入箱子的大小(輸入0離開):");
            n = int.Parse(Console.ReadLine());
            while (n != 0)
            {

                rowlen = 2 * n + 1;
                collen = rowlen;
                for (r = 0; r < rowlen; r++)
                {
                    for (c = 0; c < collen; c++)
                    {
                        if (r == c || r == rowlen - 1 || r == 0 || c == 0 || c == collen - 1 || r + c == 2 * n)
                            Console.Write("*");
                        else
                            Console.Write(" ");
                    }
                    Console.WriteLine();
                }
                Console.Write("請輸入箱子的大小(輸入0離開):");
                n = int.Parse(Console.ReadLine());
            }
            Console.Write("程式結束");
            //Console.Read();
        }
    }
}
