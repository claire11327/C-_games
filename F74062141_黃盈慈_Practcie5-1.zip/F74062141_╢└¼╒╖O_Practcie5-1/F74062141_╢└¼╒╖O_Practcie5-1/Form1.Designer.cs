﻿namespace F74062141_黃盈慈_Practcie5_1
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.pB1 = new System.Windows.Forms.PictureBox();
            this.pB2 = new System.Windows.Forms.PictureBox();
            this.pB3 = new System.Windows.Forms.PictureBox();
            this.pB4 = new System.Windows.Forms.PictureBox();
            this.inputimg = new System.Windows.Forms.TextBox();
            this.printtext = new System.Windows.Forms.TextBox();
            this.add = new System.Windows.Forms.Button();
            this.rand = new System.Windows.Forms.Button();
            this.clear = new System.Windows.Forms.Button();
            this.gen = new System.Windows.Forms.Button();
            this.indi = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pB1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB4)).BeginInit();
            this.SuspendLayout();
            // 
            // pB1
            // 
            this.pB1.Location = new System.Drawing.Point(83, 114);
            this.pB1.Name = "pB1";
            this.pB1.Size = new System.Drawing.Size(123, 118);
            this.pB1.TabIndex = 0;
            this.pB1.TabStop = false;
            // 
            // pB2
            // 
            this.pB2.Location = new System.Drawing.Point(204, 114);
            this.pB2.Name = "pB2";
            this.pB2.Size = new System.Drawing.Size(123, 118);
            this.pB2.TabIndex = 1;
            this.pB2.TabStop = false;
            // 
            // pB3
            // 
            this.pB3.Location = new System.Drawing.Point(82, 231);
            this.pB3.Name = "pB3";
            this.pB3.Size = new System.Drawing.Size(123, 118);
            this.pB3.TabIndex = 2;
            this.pB3.TabStop = false;
            // 
            // pB4
            // 
            this.pB4.Location = new System.Drawing.Point(204, 231);
            this.pB4.Name = "pB4";
            this.pB4.Size = new System.Drawing.Size(123, 118);
            this.pB4.TabIndex = 3;
            this.pB4.TabStop = false;
            // 
            // inputimg
            // 
            this.inputimg.Font = new System.Drawing.Font("微軟正黑體", 9F);
            this.inputimg.Location = new System.Drawing.Point(409, 114);
            this.inputimg.Name = "inputimg";
            this.inputimg.Size = new System.Drawing.Size(175, 27);
            this.inputimg.TabIndex = 4;
            // 
            // printtext
            // 
            this.printtext.Font = new System.Drawing.Font("微軟正黑體", 9F);
            this.printtext.Location = new System.Drawing.Point(409, 207);
            this.printtext.Multiline = true;
            this.printtext.Name = "printtext";
            this.printtext.ReadOnly = true;
            this.printtext.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.printtext.Size = new System.Drawing.Size(303, 171);
            this.printtext.TabIndex = 5;
            // 
            // add
            // 
            this.add.Font = new System.Drawing.Font("微軟正黑體", 9F);
            this.add.Location = new System.Drawing.Point(637, 115);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(75, 26);
            this.add.TabIndex = 6;
            this.add.Text = "add";
            this.add.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.add.UseVisualStyleBackColor = true;
            this.add.Click += new System.EventHandler(this.add_Click);
            // 
            // rand
            // 
            this.rand.Font = new System.Drawing.Font("微軟正黑體", 9F);
            this.rand.Location = new System.Drawing.Point(411, 162);
            this.rand.Name = "rand";
            this.rand.Size = new System.Drawing.Size(85, 27);
            this.rand.TabIndex = 7;
            this.rand.Text = "random";
            this.rand.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.rand.UseVisualStyleBackColor = true;
            this.rand.Click += new System.EventHandler(this.rand_Click);
            // 
            // clear
            // 
            this.clear.Font = new System.Drawing.Font("微軟正黑體", 9F);
            this.clear.Location = new System.Drawing.Point(637, 395);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(75, 28);
            this.clear.TabIndex = 8;
            this.clear.Text = "clear";
            this.clear.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.clear.UseVisualStyleBackColor = true;
            this.clear.Click += new System.EventHandler(this.clear_Click);
            // 
            // gen
            // 
            this.gen.Font = new System.Drawing.Font("微軟正黑體", 9F);
            this.gen.Location = new System.Drawing.Point(547, 443);
            this.gen.Name = "gen";
            this.gen.Size = new System.Drawing.Size(207, 42);
            this.gen.TabIndex = 9;
            this.gen.Text = "generate";
            this.gen.UseVisualStyleBackColor = true;
            this.gen.Click += new System.EventHandler(this.gen_Click);
            // 
            // indi
            // 
            this.indi.AutoSize = true;
            this.indi.Font = new System.Drawing.Font("微軟正黑體", 12F);
            this.indi.Location = new System.Drawing.Point(406, 70);
            this.indi.Name = "indi";
            this.indi.Size = new System.Drawing.Size(183, 25);
            this.indi.TabIndex = 11;
            this.indi.Text = "input image name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(139, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 15);
            this.label1.TabIndex = 12;
            this.label1.Text = "label1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(837, 608);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.indi);
            this.Controls.Add(this.gen);
            this.Controls.Add(this.clear);
            this.Controls.Add(this.rand);
            this.Controls.Add(this.add);
            this.Controls.Add(this.printtext);
            this.Controls.Add(this.inputimg);
            this.Controls.Add(this.pB4);
            this.Controls.Add(this.pB3);
            this.Controls.Add(this.pB2);
            this.Controls.Add(this.pB1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pB1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pB1;
        private System.Windows.Forms.PictureBox pB2;
        private System.Windows.Forms.PictureBox pB3;
        private System.Windows.Forms.PictureBox pB4;
        private System.Windows.Forms.TextBox inputimg;
        private System.Windows.Forms.TextBox printtext;
        private System.Windows.Forms.Button add;
        private System.Windows.Forms.Button rand;
        private System.Windows.Forms.Button clear;
        private System.Windows.Forms.Button gen;
        private System.Windows.Forms.Label indi;
        private System.Windows.Forms.Label label1;
    }
}

