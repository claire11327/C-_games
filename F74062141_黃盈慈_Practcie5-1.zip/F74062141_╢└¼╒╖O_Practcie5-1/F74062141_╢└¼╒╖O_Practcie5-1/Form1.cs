﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace F74062141_黃盈慈_Practcie5_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string[] img = { "road", "duck", "grassland", "church", "boat", "bridge" };
        string[] chosen = new string[4];
        int num = 0;
        int[] imgnum = new int[4];
        bool exist = false;

        private void Form1_Load(object sender, EventArgs e)
        {
            label1.Visible = false;
        }
        private void add_Click(object sender, EventArgs e)
        {
            for(int i = 0;i < 6; i++)
            {
                if(inputimg.Text == img[i])
                {
                    exist = true;
                    imgnum[num] = i;
                    print(i);
                    num++;
                    break;
                }
            }
            if (!exist) { MessageBox.Show("no image with name:" + inputimg.Text + ".jpg", "錯誤"); }

        }

        private void rand_Click(object sender, EventArgs e)
        {
            Random ran = new Random();
            num += 4;
            for(int i = 0;i < 4; i++)
            {
                imgnum[i] = ran.Next(0, 6);
                for(int j = 0; j < i;j ++)
                {
                    while(imgnum[i] == imgnum[j])
                    {
                        imgnum[i] = ran.Next(0, 6);
                        j = 0;
                    }
                    
                }
                print(imgnum[i]);
            }
            
        }

        private void clear_Click(object sender, EventArgs e)
        {
            printtext.Text = "";
            pB1.Image = null;
            pB2.Image = null;
            pB3.Image = null;
            pB4.Image = null;
            num = 0;
            for (int i = 0; i < 4; i++)
            {
                imgnum[i] = 0;
            }
            exist = false;
        }

        private void gen_Click(object sender, EventArgs e)
        {
            if (num == 4)
            {
                pB1.SizeMode = PictureBoxSizeMode.Zoom;
                pB2.SizeMode = PictureBoxSizeMode.Zoom;
                pB3.SizeMode = PictureBoxSizeMode.Zoom;
                pB4.SizeMode = PictureBoxSizeMode.Zoom;
                pB1.Image = Image.FromFile(@"../../../pic/" + img[imgnum[0]] + ".jpg");
                pB2.Image = Image.FromFile(@"../../../pic/" + img[imgnum[1]] + ".jpg");
                pB3.Image = Image.FromFile(@"../../../pic/" + img[imgnum[2]] + ".jpg");
                pB4.Image = Image.FromFile(@"../../../pic/" + img[imgnum[3]] + ".jpg");
            }
            else if(num < 4)
                MessageBox.Show("less than gallery slots(min 4)", "錯誤");
            else
                MessageBox.Show("out of gallery slots(max 4)", "錯誤");

        }

        private void print(int i)
        {
            printtext.Text += img[i] + ".jpg has been added.\r\n";
        }
        
    }
}
