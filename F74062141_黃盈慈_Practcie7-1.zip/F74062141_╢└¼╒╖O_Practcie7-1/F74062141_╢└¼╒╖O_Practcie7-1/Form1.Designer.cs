﻿namespace F74062141_黃盈慈_Practcie7_1
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pname = new System.Windows.Forms.Label();
            this.playername = new System.Windows.Forms.TextBox();
            this.His = new System.Windows.Forms.TextBox();
            this.clearHis = new System.Windows.Forms.Button();
            this.start = new System.Windows.Forms.Button();
            this.restart = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.HP = new System.Windows.Forms.Label();
            this.score = new System.Windows.Forms.Label();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.changename = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pname
            // 
            this.pname.AutoSize = true;
            this.pname.Font = new System.Drawing.Font("微軟正黑體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.pname.Location = new System.Drawing.Point(540, 55);
            this.pname.Name = "pname";
            this.pname.Size = new System.Drawing.Size(77, 35);
            this.pname.TabIndex = 0;
            this.pname.Text = "玩家:";
            // 
            // playername
            // 
            this.playername.Location = new System.Drawing.Point(614, 130);
            this.playername.Name = "playername";
            this.playername.Size = new System.Drawing.Size(100, 25);
            this.playername.TabIndex = 1;
            this.playername.Text = "player1";
            this.playername.MouseDown += new System.Windows.Forms.MouseEventHandler(this.playername_MouseDown);
            // 
            // His
            // 
            this.His.Location = new System.Drawing.Point(546, 184);
            this.His.Multiline = true;
            this.His.Name = "His";
            this.His.ReadOnly = true;
            this.His.Size = new System.Drawing.Size(308, 212);
            this.His.TabIndex = 2;
            // 
            // clearHis
            // 
            this.clearHis.Location = new System.Drawing.Point(722, 447);
            this.clearHis.Name = "clearHis";
            this.clearHis.Size = new System.Drawing.Size(132, 30);
            this.clearHis.TabIndex = 3;
            this.clearHis.Text = "清除紀錄";
            this.clearHis.UseVisualStyleBackColor = true;
            this.clearHis.Click += new System.EventHandler(this.clearHis_Click);
            // 
            // start
            // 
            this.start.Location = new System.Drawing.Point(28, 458);
            this.start.Name = "start";
            this.start.Size = new System.Drawing.Size(115, 32);
            this.start.TabIndex = 4;
            this.start.Text = "開始";
            this.start.UseVisualStyleBackColor = true;
            this.start.Click += new System.EventHandler(this.start_Click);
            // 
            // restart
            // 
            this.restart.Location = new System.Drawing.Point(166, 454);
            this.restart.Name = "restart";
            this.restart.Size = new System.Drawing.Size(121, 36);
            this.restart.TabIndex = 5;
            this.restart.Text = "重新開始";
            this.restart.UseVisualStyleBackColor = true;
            this.restart.Click += new System.EventHandler(this.restart_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(424, 438);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 15);
            this.label1.TabIndex = 6;
            this.label1.Text = "分數:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(306, 438);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 15);
            this.label2.TabIndex = 7;
            this.label2.Text = "生命:";
            // 
            // HP
            // 
            this.HP.AutoSize = true;
            this.HP.Location = new System.Drawing.Point(306, 475);
            this.HP.Name = "HP";
            this.HP.Size = new System.Drawing.Size(0, 15);
            this.HP.TabIndex = 8;
            // 
            // score
            // 
            this.score.AutoSize = true;
            this.score.Location = new System.Drawing.Point(424, 475);
            this.score.Name = "score";
            this.score.Size = new System.Drawing.Size(0, 15);
            this.score.TabIndex = 9;
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(28, 385);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(481, 11);
            this.progressBar1.TabIndex = 11;
            this.progressBar1.Value = 100;
            // 
            // changename
            // 
            this.changename.Location = new System.Drawing.Point(748, 130);
            this.changename.Name = "changename";
            this.changename.Size = new System.Drawing.Size(106, 26);
            this.changename.TabIndex = 12;
            this.changename.Text = "修改名字";
            this.changename.UseVisualStyleBackColor = true;
            this.changename.Click += new System.EventHandler(this.changename_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 3000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(28, 68);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(496, 341);
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(897, 517);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.changename);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.score);
            this.Controls.Add(this.HP);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.restart);
            this.Controls.Add(this.start);
            this.Controls.Add(this.clearHis);
            this.Controls.Add(this.His);
            this.Controls.Add(this.playername);
            this.Controls.Add(this.pname);
            this.KeyPreview = true;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label pname;
        private System.Windows.Forms.TextBox playername;
        private System.Windows.Forms.TextBox His;
        private System.Windows.Forms.Button clearHis;
        private System.Windows.Forms.Button start;
        private System.Windows.Forms.Button restart;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label HP;
        private System.Windows.Forms.Label score;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Button changename;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

