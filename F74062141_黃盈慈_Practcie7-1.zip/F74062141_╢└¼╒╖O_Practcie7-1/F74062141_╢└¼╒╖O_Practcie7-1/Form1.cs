﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace F74062141_黃盈慈_Practcie7_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        List<Label> all_label = new List<Label>();
        int HPvalue = 10;
        int Sc = 0;
        bool Keyevent = false;
        int time_interval = 1500;
        int y = 10;
        


        private void Form1_Load(object sender, EventArgs e)
        {
            //確認或產生紀錄文件檔
            string filename = "score.txt";
            if (!Directory.Exists(filename)) {
                FileInfo fInfo = new FileInfo(filename);
                FileStream fs = fInfo.Create();
                fs.Close();
            }
            System.IO.File.WriteAllText(filename, string.Empty);
            
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.Image = Image.FromFile(@"../../../pic/background.jpg");
            

            playername.Text = "player1";
            pname.Text = "玩家:" + playername.Text;
            
            init();
            
        }

        private void init()
        {
            restart.Enabled = false;
            HPvalue = 10;
            HP.Text = HPvalue.ToString();
            Sc = 0;
            score.Text = Sc.ToString();
            y = 10;
            changename.Enabled = false;
            Keyevent = true;
            playername.Enabled = false;
            His.Enabled = false;
            timer1.Interval = time_interval;


            foreach (Label lb1 in all_label)
            {
                lb1.Dispose();
            }
            all_label.Clear();
        }


        //// ***********Start Buttom*************** //

        private void start_Click(object sender, EventArgs e)
        {
            init();
            timer1.Start();
            timer2.Start();
            start.Enabled = false;
            restart.Enabled = true;
        }
        private void restart_Click(object sender, EventArgs e)
        {
            init();
            timer1.Start();
            timer2.Start();
            start.Enabled = false;
            restart.Enabled = true;
        }


        // ***********Timer tick*************** //

        private void timer1_Tick(object sender, EventArgs e)
        {
            //Set label
            Label lb1 = new Label();
            Label_initset(lb1);

            all_label.Add(lb1);
            this.Controls.Add(lb1);
            lb1.BringToFront();
            if (HPvalue <= 0)
            {
                timer1.Stop();
            }
        }



       
        private void timer2_Tick(object sender, EventArgs e)
        {
            
            foreach (Label lb1 in all_label)
            {
                lb1.Top += y;
                Label_Backcolor(lb1);

                if (lb1.Bottom >= progressBar1.Top)
                {
                    HPvalue--;
                    lb1.Dispose();
                    all_label.Remove(lb1);
                    if(HPvalue <= 0)
                    {                        
                        timer2.Stop();
                        GameOver();
                    }
                    HP.Text = HPvalue.ToString();
                    break;
                }
            }
            
        }


        // ***********Label set*************** //

        private void Label_initset(Label lb1)
        {
            Font f = new Font("微軟正黑體", 8, FontStyle.Regular);
            lb1.BackColor = Color.Black;
            lb1.Image = Image.FromFile(@"../../../pic/bell.png");
            lb1.AutoSize = false;
            lb1.Size = new Size(28,30);
            lb1.Font = f;
            Random rand = new Random();
            char c = (char)('A' + rand.Next(0, 26));
            lb1.Location = new Point(rand.Next(28, 300), 70);
            lb1.Text = c.ToString();
            lb1.TextAlign = ContentAlignment.BottomLeft;

        }

        private void Label_Backcolor(Label lb1)
        {
            if (lb1.Bottom > 190 && lb1.Bottom <= 210) { lb1.BackColor = Color.FromArgb(1, 18, 26); }
            else if (lb1.Bottom > 210 && lb1.Bottom <= 270) { lb1.BackColor = Color.FromArgb(2, 48, 71); }
            else if (lb1.Bottom > 270) { lb1.BackColor = Color.FromArgb(9, 65, 92); }
        }


        // ***********Game Over*************** //

        private void GameOver()
        {
            //寫入檔案
            string filename = "score.txt";
            FileInfo fInfo = new FileInfo(filename);
            StreamWriter sw = fInfo.AppendText();
            sw.WriteLine("玩家:" + playername.Text + "獲得" + score.Text + "分，在" + System.DateTime.Now);
            sw.Flush();
            sw.Close();
            //讀入檔案
            string str = "";
            StreamReader sr = new StreamReader(filename);
            His.Text = "";
            while ((str = sr.ReadLine()) != null){
                His.Text += str + "\r\n";
            }
            
            sr.Close();

            
            HP.Text = HPvalue.ToString();
            stoptime();
            
        }


        private void stoptime()
        {
            timer1.Enabled = false;
            timer2.Enabled = false;
            Keyevent = false;
            restart.Enabled = false;
            start.Enabled = true;
            changename.Enabled = true;
            playername.Enabled = false;
            //His.Enabled = true;
            Keyevent = false;

        }

        // ***********Key event*************** //

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (Keyevent)
            {
                //MessageBox.Show("Touch");
                foreach (Label lb1 in all_label)
                {
                    if (e.KeyCode.ToString() == lb1.Text.ToString())
                    {
                        Sc++;
                        His.Text = "yes";
                        score.Text = Sc.ToString();
                        if (time_interval > 10)
                        {
                            time_interval -= 10;
                        }
                        y++;
                        lb1.Dispose();
                        all_label.Remove(lb1);
                        His.Text = "";
                        break;
                    }
                    else { Sc--; score.Text = Sc.ToString(); }
                }
            }
            
        }

        //// ***********History & Name*************** //

        private void changename_Click(object sender, EventArgs e)
        {
            pname.Text = "玩家:" + playername.Text;

        }
        private void clearHis_Click(object sender, EventArgs e)
        {
            string filename = "score.txt";
            System.IO.File.WriteAllText(filename, string.Empty);
            His.Text = "";
            
        }

        private void playername_MouseDown(object sender, MouseEventArgs e)
        {
            playername.Text = "";
        }
        
    }
}
