﻿namespace F74062141_黃盈慈_Bonus7_1
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.txtDest = new System.Windows.Forms.TextBox();
            this.txtPad = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.createfile = new System.Windows.Forms.Button();
            this.savefile = new System.Windows.Forms.Button();
            this.movefile = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtDest
            // 
            this.txtDest.Location = new System.Drawing.Point(196, 405);
            this.txtDest.Name = "txtDest";
            this.txtDest.Size = new System.Drawing.Size(147, 25);
            this.txtDest.TabIndex = 0;
            // 
            // txtPad
            // 
            this.txtPad.Location = new System.Drawing.Point(109, 55);
            this.txtPad.Multiline = true;
            this.txtPad.Name = "txtPad";
            this.txtPad.Size = new System.Drawing.Size(391, 306);
            this.txtPad.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(39, 408);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "目的路徑";
            // 
            // createfile
            // 
            this.createfile.Location = new System.Drawing.Point(42, 491);
            this.createfile.Name = "createfile";
            this.createfile.Size = new System.Drawing.Size(75, 23);
            this.createfile.TabIndex = 3;
            this.createfile.Text = "建立檔案";
            this.createfile.UseVisualStyleBackColor = true;
            this.createfile.Click += new System.EventHandler(this.createfile_Click);
            // 
            // savefile
            // 
            this.savefile.Location = new System.Drawing.Point(268, 491);
            this.savefile.Name = "savefile";
            this.savefile.Size = new System.Drawing.Size(75, 23);
            this.savefile.TabIndex = 4;
            this.savefile.Text = "存檔";
            this.savefile.UseVisualStyleBackColor = true;
            this.savefile.Click += new System.EventHandler(this.savefile_Click);
            // 
            // movefile
            // 
            this.movefile.Location = new System.Drawing.Point(526, 491);
            this.movefile.Name = "movefile";
            this.movefile.Size = new System.Drawing.Size(75, 23);
            this.movefile.TabIndex = 5;
            this.movefile.Text = "搬移";
            this.movefile.UseVisualStyleBackColor = true;
            this.movefile.Click += new System.EventHandler(this.movefile_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(686, 550);
            this.Controls.Add(this.movefile);
            this.Controls.Add(this.savefile);
            this.Controls.Add(this.createfile);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtPad);
            this.Controls.Add(this.txtDest);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtDest;
        private System.Windows.Forms.TextBox txtPad;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button createfile;
        private System.Windows.Forms.Button savefile;
        private System.Windows.Forms.Button movefile;
    }
}

