﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace F74062141_黃盈慈_Bonus7_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void createfile_Click(object sender, EventArgs e)
        {
            string filename = "myFile.txt";
            FileInfo fInfo = new FileInfo(filename);
            FileStream fs = fInfo.Create();
            MessageBox.Show("創建成功");
            fs.Close();
        }

        private void savefile_Click(object sender, EventArgs e)
        {
            string filename = "myFile.txt";
            FileInfo fInfo = new FileInfo(filename);
            StreamWriter sw = fInfo.AppendText();
            sw.Write(txtPad.Text);
            sw.Flush();
            sw.Close();
            MessageBox.Show("資料已加入");
        }

        private void movefile_Click(object sender, EventArgs e)
        {
            string filename = "myFile.txt";
            FileInfo fInfo = new FileInfo(filename);
            FileInfo DestInfo = new FileInfo(txtDest.Text);
            fInfo.MoveTo(@txtDest.Text);
            MessageBox.Show("搬移成功");
            txtDest.Text = "";
        }
    }
}
