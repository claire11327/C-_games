﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int r = 0, c = 0, c1 = 0,r1 = 0,c2 = 0, r2 = 0 ,tmp = 0,sortindex = 0; ;
            int[,] ary1 = new int[10, 10];
            int[,] ary2 = new int[10, 10];
            int[,] ans;
            int[] anssort;
            Console.WriteLine("請輸入矩陣一(輸入空行完成):");
            string temp = Console.ReadLine();
            while(temp.Length != 0)
            {
                string[] split1 = temp.Split( );
                foreach (string s in split1)
                {
                    ary1[r, c] = int.Parse(s);
                    c++;
                }
                temp = Console.ReadLine();
                r++;
                r1 = r;
                c1 = c;
                c = 0;
            }
            r = 0;

            //第二個
            Console.WriteLine("請輸入矩陣二(輸入空行完成):");
            temp = Console.ReadLine();
            while (temp.Length != 0)
            {
                string[] split1 = temp.Split();
                foreach (string s in split1)
                {
                    ary2[r, c] = int.Parse(s);
                    c++;
                }
                temp = Console.ReadLine();
                r++;
                r2 = r;
                c2 = c;
                c = 0;
            }

            ans = new int[r1, c2];
            anssort = new int[r1*c2];



            if (r2 != c1)
            {
                Console.WriteLine("矩陣大小不一致，無法相乘");
            }
            else
            {
                Console.WriteLine("矩陣相乘的結果為:");
                for (r = 0; r < r1; r++)
                {
                    
                    for (c = 0; c < c2; c++)
                    {
                        //
                        for (int ctemp = 0; ctemp < c1; ctemp++)
                        {
                            tmp = ary1[r, ctemp] * ary2[ctemp, c] + tmp;
                        }
                        //
                        ans[r, c] = tmp;
                        anssort[sortindex] = tmp;
                        tmp = 0;
                        sortindex++;
                    }
                }
            }
            

            for (r = 0; r < r1; r++)
            {
                for (c = 0; c < c2; c++)
                {
                    Console.Write(ans[r, c]);
                    Console.Write(" ");
                }
                Console.WriteLine();

            }
            
            Console.WriteLine("排序後的結果為:");
            Array.Sort(anssort);
            for (r = 0; r < r1; r++)
            {
                for (c = 0; c < c2; c++)
                {
                    Console.Write(anssort[c+r*c2]);
                    Console.Write(" ");
                }
                Console.WriteLine();

            }

   
                        //一個迴圈分離每一行ar1
                            //紀錄此矩陣有幾行

                            //一個迴圈分離每個數字
                                //轉字串為數字
                                //紀錄該行有幾個數字

                        //一個迴圈分離每一行
                            //紀錄此矩陣有幾行

                            //一個迴圈分離每個數字
                                //轉字串為數字
                                //紀錄該行有幾個數字

                        //確認c1 == r2
                        //result

            Console.Read();
            return;
        }
    }
}
