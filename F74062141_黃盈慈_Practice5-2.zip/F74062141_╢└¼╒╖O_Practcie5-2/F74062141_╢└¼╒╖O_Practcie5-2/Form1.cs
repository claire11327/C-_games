﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace F74062141_黃盈慈_Practcie5_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            sentence_location();
        }

        private void sentence_location()
        {
            sentence_label.Font = new Font("標楷體", f_size, FontStyle.Regular);
            int sent_location_height = 270 - (sentence_label.Height );
            int sent_location_Width = (this.Width / 2) - (sentence_label.Width / 2);
            string b = "";
            label1.Text = sentence_label.Width.ToString(b );
            sentence_label.Location = new Point(sent_location_Width, sent_location_height);
            
        }

        private void set_s_change() {
            if (sentence_label.Width < (this.Width - 100))
            { sentence_location(); }
            else
            {
                MessageBox.Show("out of space");
                f_size = 9;
                sentence_location();
            }
        }

        //s change
        private void s_1_CheckedChanged(object sender, EventArgs e)
        {
            sentence_label.Text = s_1.Text;
            set_s_change();       
        }

        private void s_2_CheckedChanged(object sender, EventArgs e)
        {
            sentence_label.Text = s_2.Text;
            set_s_change();
        }

        private void s_3_CheckedChanged(object sender, EventArgs e)
        {
            sentence_label.Text = s_3.Text;
            set_s_change();
        }

        private void s_4_CheckedChanged(object sender, EventArgs e)
        {
            sentence_label.Text = s_4.Text;
            set_s_change();
        }


        //f change
        float f_size = 12;
        private void f_Bold_CheckedChanged(object sender, EventArgs e)
        {
            sentence_label.Font = new Font("標楷體", f_size, FontStyle.Bold);
        }

        private void f_Italic_CheckedChanged(object sender, EventArgs e)
        {
            sentence_label.Font = new Font("標楷體", f_size, FontStyle.Italic);
        }

        private void f_regular_CheckedChanged(object sender, EventArgs e)
        {
            sentence_label.Font = new Font("標楷體", f_size, FontStyle.Regular);
        }

        private void f_underline_CheckedChanged(object sender, EventArgs e)
        {
            sentence_label.Font = new Font("標楷體", f_size, FontStyle.Underline);
        }

        private void f_big_Click(object sender, EventArgs e)
        {
            f_size++;
            if (sentence_label.Width < (this.Width-100))
            { sentence_location(); }
            else
            { MessageBox.Show("out of space"); }            
        }
        private void f_big_KeyDown(object sender, KeyEventArgs e)
        {
        }

        private void f_small_Click(object sender, EventArgs e)
        {
            f_size--;            
            if (f_size > 0)
            { sentence_location(); }
            else
            { MessageBox.Show("to small to be seen"); }
        }

        //p change
        private void p_1_CheckedChanged(object sender, EventArgs e)
        {
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.Image = Image.FromFile(@"../../../pic/doge.png");
        }

        private void p_2_CheckedChanged(object sender, EventArgs e)
        {
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.Image = Image.FromFile(@"../../../pic/evil_patrick.png");
        }

        private void p_3_CheckedChanged(object sender, EventArgs e)
        {
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.Image = Image.FromFile(@"../../../pic/excuse_me_wtf.png");
        }

        private void p_4_CheckedChanged(object sender, EventArgs e)
        {
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.Image = Image.FromFile(@"../../../pic/just_do_it.png");
        }

        private void random_Click(object sender, EventArgs e)
        {
            Random rand = new Random();
            int[] j = new int[3];
            for(int i = 0;i < 3;i++)
                j[i] = rand.Next(0, 4);
            call(j);
        }
        private void call(int[] j)
        {

            switch (j[0])
            {
                case 0:
                    p_1_CheckedChanged(null, null);
                    break;
                case 1:
                    p_2_CheckedChanged(null, null);
                    break;
                case 2:
                    p_3_CheckedChanged(null, null);
                    break;
                case 3:
                    p_4_CheckedChanged(null, null);
                    break;
            }
            switch (j[1])
            {
                case 0:
                    f_Bold_CheckedChanged(null, null);
                    break;
                case 1:
                    f_Italic_CheckedChanged(null, null);
                    break;
                case 2:
                    f_regular_CheckedChanged(null, null);
                    break;
                case 3:
                    f_underline_CheckedChanged(null, null);
                    break;
            }
            switch (j[2])
            {
                case 0:
                    s_1_CheckedChanged(null, null);
                    break;
                case 1:
                    s_2_CheckedChanged(null, null);
                    break;
                case 2:
                    s_3_CheckedChanged(null, null);
                    break;
                case 3:
                    s_4_CheckedChanged(null, null);
                    break;
            }
            sentence_location();
        }

        
    }
}
