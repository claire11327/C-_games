﻿namespace F74062141_黃盈慈_Practcie5_2
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.tab = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.p_4 = new System.Windows.Forms.RadioButton();
            this.p_3 = new System.Windows.Forms.RadioButton();
            this.p_2 = new System.Windows.Forms.RadioButton();
            this.p_1 = new System.Windows.Forms.RadioButton();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.f_small = new System.Windows.Forms.Button();
            this.f_big = new System.Windows.Forms.Button();
            this.f_underline = new System.Windows.Forms.RadioButton();
            this.f_regular = new System.Windows.Forms.RadioButton();
            this.f_Italic = new System.Windows.Forms.RadioButton();
            this.f_Bold = new System.Windows.Forms.RadioButton();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.s_4 = new System.Windows.Forms.RadioButton();
            this.s_3 = new System.Windows.Forms.RadioButton();
            this.s_2 = new System.Windows.Forms.RadioButton();
            this.s_1 = new System.Windows.Forms.RadioButton();
            this.random = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.sentence_label = new System.Windows.Forms.Label();
            this.tab.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // tab
            // 
            this.tab.Controls.Add(this.tabPage1);
            this.tab.Controls.Add(this.tabPage2);
            this.tab.Controls.Add(this.tabPage3);
            this.tab.Font = new System.Drawing.Font("微軟正黑體", 9F);
            this.tab.Location = new System.Drawing.Point(142, 43);
            this.tab.Multiline = true;
            this.tab.Name = "tab";
            this.tab.SelectedIndex = 0;
            this.tab.Size = new System.Drawing.Size(677, 173);
            this.tab.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.p_4);
            this.tabPage1.Controls.Add(this.p_3);
            this.tabPage1.Controls.Add(this.p_2);
            this.tabPage1.Controls.Add(this.p_1);
            this.tabPage1.Location = new System.Drawing.Point(4, 28);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(669, 141);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "image";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // p_4
            // 
            this.p_4.AutoSize = true;
            this.p_4.Location = new System.Drawing.Point(332, 73);
            this.p_4.Name = "p_4";
            this.p_4.Size = new System.Drawing.Size(68, 23);
            this.p_4.TabIndex = 11;
            this.p_4.TabStop = true;
            this.p_4.Text = "Doge";
            this.p_4.UseVisualStyleBackColor = true;
            this.p_4.CheckedChanged += new System.EventHandler(this.p_4_CheckedChanged);
            // 
            // p_3
            // 
            this.p_3.AutoSize = true;
            this.p_3.Location = new System.Drawing.Point(46, 73);
            this.p_3.Name = "p_3";
            this.p_3.Size = new System.Drawing.Size(105, 23);
            this.p_3.TabIndex = 10;
            this.p_3.TabStop = true;
            this.p_3.Text = "Evil Patrick";
            this.p_3.UseVisualStyleBackColor = true;
            this.p_3.CheckedChanged += new System.EventHandler(this.p_3_CheckedChanged);
            // 
            // p_2
            // 
            this.p_2.AutoSize = true;
            this.p_2.Location = new System.Drawing.Point(332, 16);
            this.p_2.Name = "p_2";
            this.p_2.Size = new System.Drawing.Size(102, 23);
            this.p_2.TabIndex = 9;
            this.p_2.TabStop = true;
            this.p_2.Text = "Excuse Me";
            this.p_2.UseVisualStyleBackColor = true;
            this.p_2.CheckedChanged += new System.EventHandler(this.p_2_CheckedChanged);
            // 
            // p_1
            // 
            this.p_1.AutoSize = true;
            this.p_1.Location = new System.Drawing.Point(46, 16);
            this.p_1.Name = "p_1";
            this.p_1.Size = new System.Drawing.Size(94, 23);
            this.p_1.TabIndex = 8;
            this.p_1.TabStop = true;
            this.p_1.Text = "Just Do It";
            this.p_1.UseVisualStyleBackColor = true;
            this.p_1.CheckedChanged += new System.EventHandler(this.p_1_CheckedChanged);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.f_small);
            this.tabPage2.Controls.Add(this.f_big);
            this.tabPage2.Controls.Add(this.f_underline);
            this.tabPage2.Controls.Add(this.f_regular);
            this.tabPage2.Controls.Add(this.f_Italic);
            this.tabPage2.Controls.Add(this.f_Bold);
            this.tabPage2.Location = new System.Drawing.Point(4, 28);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(669, 141);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "font style";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // f_small
            // 
            this.f_small.Location = new System.Drawing.Point(457, 75);
            this.f_small.Name = "f_small";
            this.f_small.Size = new System.Drawing.Size(136, 29);
            this.f_small.TabIndex = 9;
            this.f_small.Text = "Font Size -";
            this.f_small.UseVisualStyleBackColor = true;
            this.f_small.Click += new System.EventHandler(this.f_small_Click);
            // 
            // f_big
            // 
            this.f_big.Location = new System.Drawing.Point(457, 18);
            this.f_big.Name = "f_big";
            this.f_big.Size = new System.Drawing.Size(136, 29);
            this.f_big.TabIndex = 8;
            this.f_big.Text = "Font Size +";
            this.f_big.UseVisualStyleBackColor = true;
            this.f_big.Click += new System.EventHandler(this.f_big_Click);
            this.f_big.KeyDown += new System.Windows.Forms.KeyEventHandler(this.f_big_KeyDown);
            // 
            // f_underline
            // 
            this.f_underline.AutoSize = true;
            this.f_underline.Location = new System.Drawing.Point(217, 75);
            this.f_underline.Name = "f_underline";
            this.f_underline.Size = new System.Drawing.Size(99, 23);
            this.f_underline.TabIndex = 7;
            this.f_underline.TabStop = true;
            this.f_underline.Text = "Underline";
            this.f_underline.UseVisualStyleBackColor = true;
            this.f_underline.CheckedChanged += new System.EventHandler(this.f_underline_CheckedChanged);
            // 
            // f_regular
            // 
            this.f_regular.AutoSize = true;
            this.f_regular.Location = new System.Drawing.Point(22, 75);
            this.f_regular.Name = "f_regular";
            this.f_regular.Size = new System.Drawing.Size(85, 23);
            this.f_regular.TabIndex = 6;
            this.f_regular.TabStop = true;
            this.f_regular.Text = "Regular";
            this.f_regular.UseVisualStyleBackColor = true;
            this.f_regular.CheckedChanged += new System.EventHandler(this.f_regular_CheckedChanged);
            // 
            // f_Italic
            // 
            this.f_Italic.AutoSize = true;
            this.f_Italic.Location = new System.Drawing.Point(217, 18);
            this.f_Italic.Name = "f_Italic";
            this.f_Italic.Size = new System.Drawing.Size(62, 23);
            this.f_Italic.TabIndex = 5;
            this.f_Italic.TabStop = true;
            this.f_Italic.Text = "Italic";
            this.f_Italic.UseVisualStyleBackColor = true;
            this.f_Italic.CheckedChanged += new System.EventHandler(this.f_Italic_CheckedChanged);
            // 
            // f_Bold
            // 
            this.f_Bold.AutoSize = true;
            this.f_Bold.Location = new System.Drawing.Point(22, 18);
            this.f_Bold.Name = "f_Bold";
            this.f_Bold.Size = new System.Drawing.Size(62, 23);
            this.f_Bold.TabIndex = 4;
            this.f_Bold.TabStop = true;
            this.f_Bold.Text = "Bold";
            this.f_Bold.UseVisualStyleBackColor = true;
            this.f_Bold.CheckedChanged += new System.EventHandler(this.f_Bold_CheckedChanged);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.s_4);
            this.tabPage3.Controls.Add(this.s_3);
            this.tabPage3.Controls.Add(this.s_2);
            this.tabPage3.Controls.Add(this.s_1);
            this.tabPage3.Font = new System.Drawing.Font("微軟正黑體", 9F);
            this.tabPage3.Location = new System.Drawing.Point(4, 28);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(669, 141);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "sentences";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // s_4
            // 
            this.s_4.AutoSize = true;
            this.s_4.Location = new System.Drawing.Point(32, 112);
            this.s_4.Name = "s_4";
            this.s_4.Size = new System.Drawing.Size(294, 23);
            this.s_4.TabIndex = 3;
            this.s_4.TabStop = true;
            this.s_4.Text = "Professor: This is a group project. You:";
            this.s_4.UseVisualStyleBackColor = true;
            this.s_4.CheckedChanged += new System.EventHandler(this.s_4_CheckedChanged);
            // 
            // s_3
            // 
            this.s_3.AutoSize = true;
            this.s_3.Location = new System.Drawing.Point(32, 74);
            this.s_3.Name = "s_3";
            this.s_3.Size = new System.Drawing.Size(291, 23);
            this.s_3.TabIndex = 2;
            this.s_3.TabStop = true;
            this.s_3.Text = "The moment she peeks at your phone";
            this.s_3.UseVisualStyleBackColor = true;
            this.s_3.CheckedChanged += new System.EventHandler(this.s_3_CheckedChanged);
            // 
            // s_2
            // 
            this.s_2.AutoSize = true;
            this.s_2.Location = new System.Drawing.Point(32, 40);
            this.s_2.Name = "s_2";
            this.s_2.Size = new System.Drawing.Size(221, 23);
            this.s_2.TabIndex = 1;
            this.s_2.TabStop = true;
            this.s_2.Text = "Mom: how\'s midterm? You:";
            this.s_2.UseVisualStyleBackColor = true;
            this.s_2.CheckedChanged += new System.EventHandler(this.s_2_CheckedChanged);
            // 
            // s_1
            // 
            this.s_1.AutoSize = true;
            this.s_1.Location = new System.Drawing.Point(32, 6);
            this.s_1.Name = "s_1";
            this.s_1.Size = new System.Drawing.Size(163, 23);
            this.s_1.TabIndex = 0;
            this.s_1.TabStop = true;
            this.s_1.Text = "Want Some Weed?";
            this.s_1.UseVisualStyleBackColor = true;
            this.s_1.CheckedChanged += new System.EventHandler(this.s_1_CheckedChanged);
            // 
            // random
            // 
            this.random.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.random.Location = new System.Drawing.Point(679, 222);
            this.random.Name = "random";
            this.random.Size = new System.Drawing.Size(136, 29);
            this.random.TabIndex = 10;
            this.random.Text = "random select";
            this.random.UseVisualStyleBackColor = true;
            this.random.Click += new System.EventHandler(this.random_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(146, 391);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(673, 375);
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 15);
            this.label1.TabIndex = 15;
            this.label1.Text = "label1";
            // 
            // sentence_label
            // 
            this.sentence_label.AutoSize = true;
            this.sentence_label.Location = new System.Drawing.Point(189, 293);
            this.sentence_label.Name = "sentence_label";
            this.sentence_label.Size = new System.Drawing.Size(0, 15);
            this.sentence_label.TabIndex = 16;
            this.sentence_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(938, 822);
            this.Controls.Add(this.sentence_label);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.random);
            this.Controls.Add(this.tab);
            this.KeyPreview = true;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tab.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tab;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.RadioButton s_4;
        private System.Windows.Forms.RadioButton s_3;
        private System.Windows.Forms.RadioButton s_2;
        private System.Windows.Forms.RadioButton s_1;
        private System.Windows.Forms.RadioButton p_4;
        private System.Windows.Forms.RadioButton p_3;
        private System.Windows.Forms.RadioButton p_2;
        private System.Windows.Forms.RadioButton p_1;
        private System.Windows.Forms.Button f_small;
        private System.Windows.Forms.Button f_big;
        private System.Windows.Forms.RadioButton f_underline;
        private System.Windows.Forms.RadioButton f_regular;
        private System.Windows.Forms.RadioButton f_Italic;
        private System.Windows.Forms.RadioButton f_Bold;
        private System.Windows.Forms.Button random;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label sentence_label;
    }
}

