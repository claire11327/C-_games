﻿namespace F74062141_黃盈慈_Practcie8_1
{
    partial class Form_2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.字型ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.字型ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.顏色ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.結束ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.picBox_2 = new System.Windows.Forms.PictureBox();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.sendPic_2 = new System.Windows.Forms.Button();
            this.send_2 = new System.Windows.Forms.Button();
            this.TypeBox = new System.Windows.Forms.TextBox();
            this.chatbox_2 = new System.Windows.Forms.TextBox();
            this.mycolorDialog = new System.Windows.Forms.ColorDialog();
            this.myfontDialog = new System.Windows.Forms.FontDialog();
            this.timer_2 = new System.Windows.Forms.Timer(this.components);
            this.搜尋ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBox_2)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.字型ToolStripMenuItem,
            this.搜尋ToolStripMenuItem,
            this.結束ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(924, 27);
            this.menuStrip1.TabIndex = 14;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 字型ToolStripMenuItem
            // 
            this.字型ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.字型ToolStripMenuItem1,
            this.顏色ToolStripMenuItem});
            this.字型ToolStripMenuItem.Name = "字型ToolStripMenuItem";
            this.字型ToolStripMenuItem.Size = new System.Drawing.Size(51, 23);
            this.字型ToolStripMenuItem.Text = "文字";
            // 
            // 字型ToolStripMenuItem1
            // 
            this.字型ToolStripMenuItem1.Name = "字型ToolStripMenuItem1";
            this.字型ToolStripMenuItem1.Size = new System.Drawing.Size(114, 26);
            this.字型ToolStripMenuItem1.Text = "字型";
            this.字型ToolStripMenuItem1.Click += new System.EventHandler(this.字型ToolStripMenuItem1_Click_1);
            // 
            // 顏色ToolStripMenuItem
            // 
            this.顏色ToolStripMenuItem.Name = "顏色ToolStripMenuItem";
            this.顏色ToolStripMenuItem.Size = new System.Drawing.Size(114, 26);
            this.顏色ToolStripMenuItem.Text = "顏色";
            this.顏色ToolStripMenuItem.Click += new System.EventHandler(this.顏色ToolStripMenuItem_Click);
            // 
            // 結束ToolStripMenuItem
            // 
            this.結束ToolStripMenuItem.Name = "結束ToolStripMenuItem";
            this.結束ToolStripMenuItem.Size = new System.Drawing.Size(51, 23);
            this.結束ToolStripMenuItem.Text = "結束";
            this.結束ToolStripMenuItem.Click += new System.EventHandler(this.結束ToolStripMenuItem_Click);
            // 
            // picBox_2
            // 
            this.picBox_2.Location = new System.Drawing.Point(427, 113);
            this.picBox_2.Name = "picBox_2";
            this.picBox_2.Size = new System.Drawing.Size(307, 250);
            this.picBox_2.TabIndex = 20;
            this.picBox_2.TabStop = false;
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(427, 390);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(307, 23);
            this.progressBar1.TabIndex = 19;
            // 
            // sendPic_2
            // 
            this.sendPic_2.Location = new System.Drawing.Point(760, 390);
            this.sendPic_2.Name = "sendPic_2";
            this.sendPic_2.Size = new System.Drawing.Size(85, 23);
            this.sendPic_2.TabIndex = 18;
            this.sendPic_2.Text = "傳送圖片";
            this.sendPic_2.UseVisualStyleBackColor = true;
            this.sendPic_2.Click += new System.EventHandler(this.sendPic_2_Click);
            // 
            // send_2
            // 
            this.send_2.Location = new System.Drawing.Point(318, 435);
            this.send_2.Name = "send_2";
            this.send_2.Size = new System.Drawing.Size(75, 23);
            this.send_2.TabIndex = 17;
            this.send_2.Text = "傳送";
            this.send_2.UseVisualStyleBackColor = true;
            this.send_2.Click += new System.EventHandler(this.send_2_Click);
            // 
            // TypeBox
            // 
            this.TypeBox.Location = new System.Drawing.Point(27, 433);
            this.TypeBox.Name = "TypeBox";
            this.TypeBox.Size = new System.Drawing.Size(259, 25);
            this.TypeBox.TabIndex = 16;
            this.TypeBox.Click += new System.EventHandler(this.TypeBox_Click);
            // 
            // chatbox_2
            // 
            this.chatbox_2.BackColor = System.Drawing.Color.Cornsilk;
            this.chatbox_2.Font = new System.Drawing.Font("新細明體", 9F);
            this.chatbox_2.Location = new System.Drawing.Point(27, 53);
            this.chatbox_2.Multiline = true;
            this.chatbox_2.Name = "chatbox_2";
            this.chatbox_2.ReadOnly = true;
            this.chatbox_2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.chatbox_2.Size = new System.Drawing.Size(366, 360);
            this.chatbox_2.TabIndex = 15;
            // 
            // timer_2
            // 
            this.timer_2.Tick += new System.EventHandler(this.timer_2_Tick);
            // 
            // 搜尋ToolStripMenuItem
            // 
            this.搜尋ToolStripMenuItem.Name = "搜尋ToolStripMenuItem";
            this.搜尋ToolStripMenuItem.Size = new System.Drawing.Size(51, 24);
            this.搜尋ToolStripMenuItem.Text = "搜尋";
            this.搜尋ToolStripMenuItem.Click += new System.EventHandler(this.搜尋ToolStripMenuItem_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(427, 30);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(259, 25);
            this.textBox1.TabIndex = 21;
            this.textBox1.Visible = false;
            this.textBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox1_KeyDown);
            // 
            // Form_2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(924, 527);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.picBox_2);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.sendPic_2);
            this.Controls.Add(this.send_2);
            this.Controls.Add(this.TypeBox);
            this.Controls.Add(this.chatbox_2);
            this.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Name = "Form_2";
            this.Text = "B";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBox_2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 字型ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 字型ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 顏色ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 結束ToolStripMenuItem;
        private System.Windows.Forms.PictureBox picBox_2;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Button sendPic_2;
        private System.Windows.Forms.Button send_2;
        private System.Windows.Forms.TextBox TypeBox;
        private System.Windows.Forms.TextBox chatbox_2;
        private System.Windows.Forms.ColorDialog mycolorDialog;
        private System.Windows.Forms.FontDialog myfontDialog;
        private System.Windows.Forms.Timer timer_2;
        private System.Windows.Forms.ToolStripMenuItem 搜尋ToolStripMenuItem;
        private System.Windows.Forms.TextBox textBox1;
    }
}