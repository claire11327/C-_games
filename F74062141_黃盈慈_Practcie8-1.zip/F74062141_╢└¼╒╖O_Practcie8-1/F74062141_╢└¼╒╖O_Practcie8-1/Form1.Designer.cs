﻿namespace F74062141_黃盈慈_Practcie8_1
{
    partial class Form_1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.字型ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.字型ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.顏色ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.結束ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.picBox = new System.Windows.Forms.PictureBox();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.sendPic = new System.Windows.Forms.Button();
            this.send = new System.Windows.Forms.Button();
            this.TypeBox = new System.Windows.Forms.TextBox();
            this.chatbox = new System.Windows.Forms.TextBox();
            this.mycolorDialog = new System.Windows.Forms.ColorDialog();
            this.myfontDialog = new System.Windows.Forms.FontDialog();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.搜尋ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBox)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.字型ToolStripMenuItem,
            this.搜尋ToolStripMenuItem,
            this.結束ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(905, 27);
            this.menuStrip1.TabIndex = 7;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 字型ToolStripMenuItem
            // 
            this.字型ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.字型ToolStripMenuItem1,
            this.顏色ToolStripMenuItem});
            this.字型ToolStripMenuItem.Name = "字型ToolStripMenuItem";
            this.字型ToolStripMenuItem.Size = new System.Drawing.Size(51, 23);
            this.字型ToolStripMenuItem.Text = "文字";
            // 
            // 字型ToolStripMenuItem1
            // 
            this.字型ToolStripMenuItem1.Name = "字型ToolStripMenuItem1";
            this.字型ToolStripMenuItem1.Size = new System.Drawing.Size(114, 26);
            this.字型ToolStripMenuItem1.Text = "字型";
            this.字型ToolStripMenuItem1.Click += new System.EventHandler(this.字型ToolStripMenuItem1_Click);
            // 
            // 顏色ToolStripMenuItem
            // 
            this.顏色ToolStripMenuItem.Name = "顏色ToolStripMenuItem";
            this.顏色ToolStripMenuItem.Size = new System.Drawing.Size(114, 26);
            this.顏色ToolStripMenuItem.Text = "顏色";
            this.顏色ToolStripMenuItem.Click += new System.EventHandler(this.顏色ToolStripMenuItem_Click);
            // 
            // 結束ToolStripMenuItem
            // 
            this.結束ToolStripMenuItem.Name = "結束ToolStripMenuItem";
            this.結束ToolStripMenuItem.Size = new System.Drawing.Size(51, 23);
            this.結束ToolStripMenuItem.Text = "結束";
            this.結束ToolStripMenuItem.Click += new System.EventHandler(this.結束ToolStripMenuItem_Click);
            // 
            // picBox
            // 
            this.picBox.Location = new System.Drawing.Point(424, 105);
            this.picBox.Name = "picBox";
            this.picBox.Size = new System.Drawing.Size(307, 250);
            this.picBox.TabIndex = 13;
            this.picBox.TabStop = false;
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(424, 382);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(307, 23);
            this.progressBar1.TabIndex = 12;
            // 
            // sendPic
            // 
            this.sendPic.Location = new System.Drawing.Point(757, 382);
            this.sendPic.Name = "sendPic";
            this.sendPic.Size = new System.Drawing.Size(104, 23);
            this.sendPic.TabIndex = 11;
            this.sendPic.Text = "傳送圖片";
            this.sendPic.UseVisualStyleBackColor = true;
            this.sendPic.Click += new System.EventHandler(this.sendPic_Click);
            // 
            // send
            // 
            this.send.Location = new System.Drawing.Point(315, 427);
            this.send.Name = "send";
            this.send.Size = new System.Drawing.Size(75, 23);
            this.send.TabIndex = 10;
            this.send.Text = "傳送";
            this.send.UseVisualStyleBackColor = true;
            this.send.Click += new System.EventHandler(this.send_Click);
            // 
            // TypeBox
            // 
            this.TypeBox.Location = new System.Drawing.Point(24, 425);
            this.TypeBox.Name = "TypeBox";
            this.TypeBox.Size = new System.Drawing.Size(259, 25);
            this.TypeBox.TabIndex = 9;
            this.TypeBox.TextChanged += new System.EventHandler(this.TypeBox_TextChanged);
            // 
            // chatbox
            // 
            this.chatbox.BackColor = System.Drawing.Color.Cornsilk;
            this.chatbox.Location = new System.Drawing.Point(24, 45);
            this.chatbox.Multiline = true;
            this.chatbox.Name = "chatbox";
            this.chatbox.ReadOnly = true;
            this.chatbox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.chatbox.Size = new System.Drawing.Size(366, 360);
            this.chatbox.TabIndex = 8;
            // 
            // timer
            // 
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // 搜尋ToolStripMenuItem
            // 
            this.搜尋ToolStripMenuItem.Name = "搜尋ToolStripMenuItem";
            this.搜尋ToolStripMenuItem.Size = new System.Drawing.Size(51, 24);
            this.搜尋ToolStripMenuItem.Text = "搜尋";
            this.搜尋ToolStripMenuItem.Click += new System.EventHandler(this.搜尋ToolStripMenuItem_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(424, 30);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(259, 25);
            this.textBox1.TabIndex = 22;
            this.textBox1.Visible = false;
            this.textBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox1_KeyDown);
            // 
            // Form_1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(905, 484);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.picBox);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.sendPic);
            this.Controls.Add(this.send);
            this.Controls.Add(this.TypeBox);
            this.Controls.Add(this.chatbox);
            this.Name = "Form_1";
            this.Text = "A";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 字型ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 字型ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 顏色ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 結束ToolStripMenuItem;
        private System.Windows.Forms.PictureBox picBox;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Button sendPic;
        private System.Windows.Forms.Button send;
        private System.Windows.Forms.TextBox TypeBox;
        private System.Windows.Forms.TextBox chatbox;
        private System.Windows.Forms.ColorDialog mycolorDialog;
        private System.Windows.Forms.FontDialog myfontDialog;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.ToolStripMenuItem 搜尋ToolStripMenuItem;
        private System.Windows.Forms.TextBox textBox1;
    }
}

