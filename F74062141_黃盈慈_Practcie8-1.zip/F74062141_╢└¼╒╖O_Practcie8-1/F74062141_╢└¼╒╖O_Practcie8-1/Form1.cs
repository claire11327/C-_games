﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace F74062141_黃盈慈_Practcie8_1
{
    public partial class Form_1 : Form
    {
        Form_2 f2;
        long time;
        int temp_time;
        Image img;
        char c;
        public Form_1()
        {
            InitializeComponent();
            f2 = new Form_2(this);
            f2.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }



        private void 顏色ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (mycolorDialog.ShowDialog() != DialogResult.Cancel)
            {
                chatbox.BackColor = Color.Cornsilk;
                chatbox.ForeColor = mycolorDialog.Color;
            }
        }

        private void 字型ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (myfontDialog.ShowDialog() != DialogResult.Cancel)
            {
                chatbox.Font = myfontDialog.Font;
            }
        }


        private void 結束ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void send_Click(object sender, EventArgs e)
        {
            if (c == 'B')
            {
                chatbox.Text += "\r\n";
            }
            chatbox.Text += "A:" + TypeBox.Text + "\r\n";
            f2.recvmsg("A:" + TypeBox.Text + "\r\n");
            TypeBox.Text = "";
            c = 'A';
        }



        private void TypeBox_TextChanged(object sender, EventArgs e)
        {
            chatbox.Focus();
            chatbox.SelectionStart = chatbox.Text.Length;
            chatbox.SelectionLength = 0;
            chatbox.ScrollToCaret();
            TypeBox.Focus();
        }

        private void sendPic_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Title = "Select file";
            dialog.InitialDirectory = Path.GetFullPath(Path.Combine(Application.StartupPath, @"../../../Resource/"));
            dialog.Filter = "“Image Files(*.png;*.jpg;*.gif)|*.png;*.jpg;*.gif";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                img = Image.FromFile(dialog.FileName);
                time = new FileInfo(dialog.FileName).Length;
                temp_time = (int)time;
                timer.Start();

            }
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            if (temp_time > 100)
            {
                temp_time -= 1000;
                int v = 100 - (100 * temp_time / (int)time);
                if(v <= 100)
                {
                    progressBar1.Value = 100 - (100 * temp_time / (int)time);
                }
                sendPic.Enabled = false;
            }
            else
            {
                timer.Stop();
                send_pic();
                progressBar1.Value = 0;
                sendPic.Enabled = true;

            }

        }

        private void send_pic()
        {
            f2.recvpic(img);
        }





        public void recvmsg(string str)
        {
            if(c == 'A')
            {
                chatbox.Text += "\r\n";
            }
            chatbox.Text += str;
            c = 'B';
        }
        public void recvpic(Image img)
        {
            picBox.SizeMode = PictureBoxSizeMode.Zoom;
            picBox.Image = img;
        }

        private void 搜尋ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!textBox1.Visible)
            {
                textBox1.Visible = true;
            }
            else
            {
                textBox1.Visible = false;
            }
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string str = textBox1.Text;
                if (chatbox.Text.Contains(str))
                {
                    chatbox.Focus();
                    chatbox.SelectionStart = chatbox.Text.IndexOf(str);// chatbox_2.Text.Length;
                    chatbox.SelectionLength = textBox1.Text.Length;
                    chatbox.ScrollToCaret();
                }
                else
                {
                    textBox1.Text += "沒有此字串";
                }
            }
        }

        
    }
}
