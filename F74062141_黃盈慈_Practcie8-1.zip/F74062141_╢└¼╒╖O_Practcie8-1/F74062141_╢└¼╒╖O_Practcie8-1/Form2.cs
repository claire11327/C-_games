﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace F74062141_黃盈慈_Practcie8_1
{
    public partial class Form_2 : Form
    {
        Form_1 f1;
        long time;
        int temp_time;
        Image img;
        char c;

        public Form_2(Form_1 ff)
        {
            InitializeComponent();
            f1 = ff;
        }

        private void 顏色ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (mycolorDialog.ShowDialog() != DialogResult.Cancel)
            {
                chatbox_2.BackColor = Color.Cornsilk;
                chatbox_2.ForeColor = mycolorDialog.Color;
            }
        }
        private void 字型ToolStripMenuItem1_Click_1(object sender, EventArgs e)
        {
            if (myfontDialog.ShowDialog() != DialogResult.Cancel)
            {
                chatbox_2.Font = myfontDialog.Font;
            }
        }

        private void 搜尋ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!textBox1.Visible)
            {
                textBox1.Visible = true;
            }
            else
            {
                textBox1.Visible = false;
            }
            
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter) {
                string str = textBox1.Text;
                if (chatbox_2.Text.Contains(str))
                {
                    chatbox_2.Focus();
                    chatbox_2.SelectionStart = chatbox_2.Text.IndexOf(str);// chatbox_2.Text.Length;
                    chatbox_2.SelectionLength = textBox1.Text.Length;
                    chatbox_2.ScrollToCaret();
                }
                else
                {
                    textBox1.Text += "沒有此字串";
                }
            }
        }
            
    

        private void 結束ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }



        public void send_2_Click(object sender, EventArgs e)
        {
            if (c == 'A')
            {
                chatbox_2.Text += "\r\n";
            }
            chatbox_2.Text += "B:" + TypeBox.Text + "\r\n";
            f1.recvmsg("B:" + TypeBox.Text + "\r\n");
            TypeBox.Text = "";
            c = 'B';
        }


        private void TypeBox_Click(object sender, EventArgs e)
        {
            chatbox_2.Focus();
            chatbox_2.SelectionStart = chatbox_2.Text.Length;
            chatbox_2.SelectionLength = 0;
            chatbox_2.ScrollToCaret();
            TypeBox.Focus();
        }


        private void sendPic_2_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Title = "Select file";
            dialog.InitialDirectory = Path.GetFullPath(Path.Combine(Application.StartupPath, @"../../../Resource/"));
            dialog.Filter = "“Image Files(*.png;*.jpg;*.gif)|*.png;*.jpg;*.gif";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                img = Image.FromFile(dialog.FileName);
                time = new FileInfo(dialog.FileName).Length;
                timer_2.Start();
                temp_time = (int)time;
            }
        }

        private void timer_2_Tick(object sender, EventArgs e)
        {
            if (temp_time > 1000)
            {
                temp_time -= 1000;
                int v = 100 - (100 * temp_time / (int)time);
                if (v <= 100)
                {
                    progressBar1.Value = 100 - (100 * temp_time / (int)time);
                }
                sendPic_2.Enabled = false;
            }
            else
            {
                timer_2.Stop();
                send_pic();
                progressBar1.Value = 0;
                sendPic_2.Enabled = true;

            }
        }
        
        private void send_pic()
        {
            f1.recvpic(img);
        }


        public void recvmsg(string str)
        {
            if (c == 'B')
            {
                chatbox_2.Text += "\r\n";
            }
            chatbox_2.Text += str;
            c = 'A';
        }
        public void recvpic(Image img)
        {
            picBox_2.SizeMode = PictureBoxSizeMode.Zoom;
            picBox_2.Image = img;
        }
    }
}
