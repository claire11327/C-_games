﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace F74062141_黃盈慈_Bonus8_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string filename = "文件.txt";
            if (!Directory.Exists(filename))
            {
                FileInfo fInfo = new FileInfo(filename);
                FileStream fs = fInfo.Create();
                fs.Close();
            }
        }



        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            Font f = new Font("微軟正黑體", 10, FontStyle.Regular);
            textBox1.Font = f;
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            Font f = new Font("微軟正黑體", 20, FontStyle.Regular);
            textBox1.Font = f;
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            Font f = new Font("微軟正黑體", 30, FontStyle.Regular);
            textBox1.Font = f;
        }

        private void 黃ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.ForeColor = Color.Yellow;
        }

        private void 綠ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.ForeColor = Color.Green;
        }

        private void 紅ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.ForeColor = Color.Red;
        }

        private void 儲存SToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string filename = "文件.txt";
            FileInfo fInfo = new FileInfo(filename);
            StreamWriter sw = fInfo.AppendText();
            sw.WriteLine(textBox1.Text);
            sw.Flush();
            sw.Close();
            //讀入檔案
            
        }

        private void 讀取檔案CtrlOToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            string filename = "文件.txt";
            FileInfo fInfo = new FileInfo(filename);
            string str = "";
            StreamReader sr = new StreamReader(filename);
            textBox1.Text = "";
            while ((str = sr.ReadLine()) != null)
            {
                textBox1.Text += str + "\r\n";
            }
        }

        private void 清空NCrtlNToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }

        private void 結束XToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
