﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            Random ranObj = new Random();
            int[] sum = new int[4];
            int[] n   = new int[] { 0,0,0,0};
            string[,] player = new string[4,13];
            string[] al = new string[] { "a", "b", "c", "d" };
            Console.Write("輸入y來繼續，輸入n結束:");
            string ch = Console.ReadLine();
            while (ch == "y")
            {
                for (int i = 0; i < 4; i++)
                {
                    for (int j = 0; j < 13; j++)
                    {
                        int r = ranObj.Next(0, 4);
                        while (n[r] >= 13)
                        {
                            r = ranObj.Next(0, 4);
                        }
                        int k = j + 1;
                        player[r, n[r]] = al[i] + "_" + k + " ";
                        sum[r] += k;
                        n[r]++;
                    }
                }
                for (int i = 0; i < 4; i++)
                {
                    int p = i + 1;
                    Console.Write("player{0}:", p);
                    for (int j = 0; j < 13; j++)
                    {
                        Console.Write("{0}", player[i, j]);
                    }
                    Console.WriteLine();
                }
                for (int i = 0; i < 4; i++)
                {
                    int p = i + 1;
                    if (sum[i] != 91)
                    {
                        Console.WriteLine("玩家{0}:有對子  ", p);
                        
                    }
                    else
                    {
                        int lack = 0;
                        for (int j = 0; j < 13; j++)
                        {
                            int k = j + 1;
                            string st = "_" + k;
                            if (!player[i, j].Contains(st))
                            {
                                lack++;
                            }
                                
                        }
                        if(lack == 0)
                        {
                            Console.WriteLine("玩家{0}:沒對子 ", p);
                        }
                        else
                        {
                            Console.WriteLine("玩家{0}:有對子  ,", p);
                        }
                    }
                    sum[i] = 0;
                    n[i] = 0;
                }
                for (int i = 0; i < 4; i++)
                {
                    for (int j = 0; j < 13; j++)
                    {
                        player[i, j] = "";
                    }
                }
                Console.Write("輸入y來繼續，輸入n結束:");                
                ch = Console.ReadLine();
            }
            Console.WriteLine("goodbye");
            string s = Console.ReadLine();
            Console.Read();
        }
    }
}
