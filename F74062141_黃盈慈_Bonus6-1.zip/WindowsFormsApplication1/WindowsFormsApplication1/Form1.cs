﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }
        

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            press.Text = "按了左鍵於Ｘ：" + e.X + "Y:" + e.Y;
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            int a = e.KeyValue;
            //string b = e.KeyCode;
            label1.Text = "按了menu鍵，鍵碼 :" + a;
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            //int a = e.KeyValue;
            //label1.Text = "按了menu鍵，鍵碼 :" + a;
        }
    }
}
