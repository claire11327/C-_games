﻿namespace F74062141_黃盈慈_Practcie4_1
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.signindex1 = new System.Windows.Forms.Label();
            this.signindex2 = new System.Windows.Forms.Label();
            this.passwd = new System.Windows.Forms.TextBox();
            this.signbtn = new System.Windows.Forms.Button();
            this.selectsv = new System.Windows.Forms.Label();
            this.withdraw = new System.Windows.Forms.Button();
            this.save = new System.Windows.Forms.Button();
            this.last = new System.Windows.Forms.Button();
            this.history = new System.Windows.Forms.Button();
            this.signout = new System.Windows.Forms.Button();
            this.money = new System.Windows.Forms.TextBox();
            this.w_s_mon = new System.Windows.Forms.Label();
            this.NTD = new System.Windows.Forms.Button();
            this.USD = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lastmon = new System.Windows.Forms.Label();
            this.his = new System.Windows.Forms.TextBox();
            this.menu = new System.Windows.Forms.Button();
            this.message = new System.Windows.Forms.Label();
            this.changepasswd = new System.Windows.Forms.Button();
            this.oldpsd = new System.Windows.Forms.TextBox();
            this.newpsd = new System.Windows.Forms.TextBox();
            this.check = new System.Windows.Forms.TextBox();
            this.sure = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // signindex1
            // 
            this.signindex1.AutoSize = true;
            this.signindex1.Location = new System.Drawing.Point(92, 140);
            this.signindex1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.signindex1.Name = "signindex1";
            this.signindex1.Size = new System.Drawing.Size(226, 20);
            this.signindex1.TabIndex = 0;
            this.signindex1.Text = "請輸入6 ~ 12位晶片密碼 :";
            // 
            // signindex2
            // 
            this.signindex2.AutoSize = true;
            this.signindex2.Location = new System.Drawing.Point(92, 177);
            this.signindex2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.signindex2.Name = "signindex2";
            this.signindex2.Size = new System.Drawing.Size(182, 20);
            this.signindex2.TabIndex = 1;
            this.signindex2.Text = "Enter PIN (6~12 digits)";
            // 
            // passwd
            // 
            this.passwd.Location = new System.Drawing.Point(378, 152);
            this.passwd.Margin = new System.Windows.Forms.Padding(4);
            this.passwd.Name = "passwd";
            this.passwd.Size = new System.Drawing.Size(155, 31);
            this.passwd.TabIndex = 2;
            // 
            // signbtn
            // 
            this.signbtn.Location = new System.Drawing.Point(621, 153);
            this.signbtn.Margin = new System.Windows.Forms.Padding(4);
            this.signbtn.Name = "signbtn";
            this.signbtn.Size = new System.Drawing.Size(94, 31);
            this.signbtn.TabIndex = 3;
            this.signbtn.Text = "登入";
            this.signbtn.UseVisualStyleBackColor = true;
            this.signbtn.Click += new System.EventHandler(this.sign_in);
            // 
            // selectsv
            // 
            this.selectsv.AutoSize = true;
            this.selectsv.Location = new System.Drawing.Point(312, 61);
            this.selectsv.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.selectsv.Name = "selectsv";
            this.selectsv.Size = new System.Drawing.Size(149, 20);
            this.selectsv.TabIndex = 4;
            this.selectsv.Text = "請選擇服務項目";
            // 
            // withdraw
            // 
            this.withdraw.Location = new System.Drawing.Point(304, 108);
            this.withdraw.Name = "withdraw";
            this.withdraw.Size = new System.Drawing.Size(164, 52);
            this.withdraw.TabIndex = 5;
            this.withdraw.Text = "存簿提款";
            this.withdraw.UseVisualStyleBackColor = true;
            this.withdraw.Click += new System.EventHandler(this.withdrawmon);
            // 
            // save
            // 
            this.save.Location = new System.Drawing.Point(304, 197);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(164, 52);
            this.save.TabIndex = 6;
            this.save.Text = "存簿存款";
            this.save.UseVisualStyleBackColor = true;
            this.save.Click += new System.EventHandler(this.savemon);
            // 
            // last
            // 
            this.last.Location = new System.Drawing.Point(304, 280);
            this.last.Name = "last";
            this.last.Size = new System.Drawing.Size(164, 52);
            this.last.TabIndex = 7;
            this.last.Text = "查詢餘額";
            this.last.UseVisualStyleBackColor = true;
            this.last.Click += new System.EventHandler(this.last_Click);
            // 
            // history
            // 
            this.history.Location = new System.Drawing.Point(304, 352);
            this.history.Name = "history";
            this.history.Size = new System.Drawing.Size(164, 52);
            this.history.TabIndex = 8;
            this.history.Text = "查詢歷史紀錄";
            this.history.UseVisualStyleBackColor = true;
            this.history.Click += new System.EventHandler(this.history_Click);
            // 
            // signout
            // 
            this.signout.Location = new System.Drawing.Point(304, 508);
            this.signout.Name = "signout";
            this.signout.Size = new System.Drawing.Size(164, 52);
            this.signout.TabIndex = 9;
            this.signout.Text = "登出";
            this.signout.UseVisualStyleBackColor = true;
            this.signout.Click += new System.EventHandler(this.sign_out);
            // 
            // money
            // 
            this.money.Location = new System.Drawing.Point(378, 209);
            this.money.Margin = new System.Windows.Forms.Padding(4);
            this.money.Name = "money";
            this.money.Size = new System.Drawing.Size(155, 31);
            this.money.TabIndex = 11;
            // 
            // w_s_mon
            // 
            this.w_s_mon.AutoSize = true;
            this.w_s_mon.Location = new System.Drawing.Point(92, 212);
            this.w_s_mon.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.w_s_mon.Name = "w_s_mon";
            this.w_s_mon.Size = new System.Drawing.Size(159, 20);
            this.w_s_mon.TabIndex = 10;
            this.w_s_mon.Text = "請輸入提款金額 :";
            // 
            // NTD
            // 
            this.NTD.Location = new System.Drawing.Point(592, 192);
            this.NTD.Margin = new System.Windows.Forms.Padding(4);
            this.NTD.Name = "NTD";
            this.NTD.Size = new System.Drawing.Size(94, 31);
            this.NTD.TabIndex = 12;
            this.NTD.Text = "新台幣";
            this.NTD.UseVisualStyleBackColor = true;
            this.NTD.Click += new System.EventHandler(this.NTD_Click);
            // 
            // USD
            // 
            this.USD.Location = new System.Drawing.Point(592, 234);
            this.USD.Margin = new System.Windows.Forms.Padding(4);
            this.USD.Name = "USD";
            this.USD.Size = new System.Drawing.Size(94, 31);
            this.USD.TabIndex = 13;
            this.USD.Text = "美金";
            this.USD.UseVisualStyleBackColor = true;
            this.USD.Click += new System.EventHandler(this.USD_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(680, 524);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 20);
            this.label1.TabIndex = 14;
            this.label1.Text = "label1";
            // 
            // lastmon
            // 
            this.lastmon.AutoSize = true;
            this.lastmon.Location = new System.Drawing.Point(342, 239);
            this.lastmon.Name = "lastmon";
            this.lastmon.Size = new System.Drawing.Size(0, 20);
            this.lastmon.TabIndex = 15;
            // 
            // his
            // 
            this.his.Location = new System.Drawing.Point(304, 247);
            this.his.Multiline = true;
            this.his.Name = "his";
            this.his.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.his.Size = new System.Drawing.Size(221, 25);
            this.his.TabIndex = 16;
            // 
            // menu
            // 
            this.menu.Location = new System.Drawing.Point(621, 508);
            this.menu.Name = "menu";
            this.menu.Size = new System.Drawing.Size(164, 52);
            this.menu.TabIndex = 17;
            this.menu.Text = "回目錄";
            this.menu.UseVisualStyleBackColor = true;
            this.menu.Click += new System.EventHandler(this.menu_Click);
            // 
            // message
            // 
            this.message.AutoSize = true;
            this.message.Location = new System.Drawing.Point(302, 61);
            this.message.Name = "message";
            this.message.Size = new System.Drawing.Size(0, 20);
            this.message.TabIndex = 19;
            // 
            // changepasswd
            // 
            this.changepasswd.Location = new System.Drawing.Point(304, 437);
            this.changepasswd.Name = "changepasswd";
            this.changepasswd.Size = new System.Drawing.Size(164, 52);
            this.changepasswd.TabIndex = 20;
            this.changepasswd.Text = "更改密碼";
            this.changepasswd.UseVisualStyleBackColor = true;
            this.changepasswd.Click += new System.EventHandler(this.changepasswd_Click);
            // 
            // oldpsd
            // 
            this.oldpsd.Location = new System.Drawing.Point(304, 152);
            this.oldpsd.Margin = new System.Windows.Forms.Padding(4);
            this.oldpsd.Name = "oldpsd";
            this.oldpsd.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.oldpsd.Size = new System.Drawing.Size(155, 31);
            this.oldpsd.TabIndex = 21;
            this.oldpsd.Text = "enter your old password";
            this.oldpsd.MouseClick += new System.Windows.Forms.MouseEventHandler(this.oldpsd_MouseClick);
            this.oldpsd.TextChanged += new System.EventHandler(this.oldpsd_TextChanged);
            // 
            // newpsd
            // 
            this.newpsd.Location = new System.Drawing.Point(306, 258);
            this.newpsd.Margin = new System.Windows.Forms.Padding(4);
            this.newpsd.Name = "newpsd";
            this.newpsd.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.newpsd.Size = new System.Drawing.Size(155, 31);
            this.newpsd.TabIndex = 22;
            this.newpsd.Text = "enter your new password";
            this.newpsd.MouseClick += new System.Windows.Forms.MouseEventHandler(this.newpsd_MouseClick);
            this.newpsd.TextChanged += new System.EventHandler(this.newpsd_TextChanged);
            // 
            // check
            // 
            this.check.Location = new System.Drawing.Point(306, 349);
            this.check.Margin = new System.Windows.Forms.Padding(4);
            this.check.Name = "check";
            this.check.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.check.Size = new System.Drawing.Size(155, 31);
            this.check.TabIndex = 24;
            this.check.Text = "enter your new password again";
            this.check.MouseClick += new System.Windows.Forms.MouseEventHandler(this.check_MouseClick);
            this.check.TextChanged += new System.EventHandler(this.check_TextChanged);
            // 
            // sure
            // 
            this.sure.Location = new System.Drawing.Point(334, 437);
            this.sure.Margin = new System.Windows.Forms.Padding(4);
            this.sure.Name = "sure";
            this.sure.Size = new System.Drawing.Size(94, 31);
            this.sure.TabIndex = 25;
            this.sure.Text = "確認";
            this.sure.UseVisualStyleBackColor = true;
            this.sure.Click += new System.EventHandler(this.sure_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(845, 676);
            this.Controls.Add(this.sure);
            this.Controls.Add(this.check);
            this.Controls.Add(this.newpsd);
            this.Controls.Add(this.oldpsd);
            this.Controls.Add(this.changepasswd);
            this.Controls.Add(this.message);
            this.Controls.Add(this.menu);
            this.Controls.Add(this.his);
            this.Controls.Add(this.lastmon);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.USD);
            this.Controls.Add(this.NTD);
            this.Controls.Add(this.money);
            this.Controls.Add(this.w_s_mon);
            this.Controls.Add(this.signout);
            this.Controls.Add(this.history);
            this.Controls.Add(this.last);
            this.Controls.Add(this.save);
            this.Controls.Add(this.withdraw);
            this.Controls.Add(this.selectsv);
            this.Controls.Add(this.signbtn);
            this.Controls.Add(this.passwd);
            this.Controls.Add(this.signindex2);
            this.Controls.Add(this.signindex1);
            this.Font = new System.Drawing.Font("新細明體", 12F);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label signindex1;
        private System.Windows.Forms.Label signindex2;
        private System.Windows.Forms.TextBox passwd;
        private System.Windows.Forms.Button signbtn;
        private System.Windows.Forms.Label selectsv;
        private System.Windows.Forms.Button withdraw;
        private System.Windows.Forms.Button save;
        private System.Windows.Forms.Button last;
        private System.Windows.Forms.Button history;
        private System.Windows.Forms.Button signout;
        private System.Windows.Forms.TextBox money;
        private System.Windows.Forms.Label w_s_mon;
        private System.Windows.Forms.Button NTD;
        private System.Windows.Forms.Button USD;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lastmon;
        private System.Windows.Forms.TextBox his;
        private System.Windows.Forms.Button menu;
        private System.Windows.Forms.Label message;
        private System.Windows.Forms.Button changepasswd;
        private System.Windows.Forms.TextBox oldpsd;
        private System.Windows.Forms.TextBox newpsd;
        private System.Windows.Forms.TextBox check;
        private System.Windows.Forms.Button sure;
    }
}

