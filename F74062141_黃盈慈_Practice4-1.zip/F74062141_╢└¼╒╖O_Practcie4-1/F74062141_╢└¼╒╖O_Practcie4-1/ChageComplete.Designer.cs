﻿namespace F74062141_黃盈慈_Practcie4_1
{
    partial class ChageComplete
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.suc = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // suc
            // 
            this.suc.AutoSize = true;
            this.suc.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.suc.Location = new System.Drawing.Point(45, 100);
            this.suc.Name = "suc";
            this.suc.Size = new System.Drawing.Size(197, 38);
            this.suc.TabIndex = 0;
            this.suc.Text = "成功更改密碼";
            // 
            // ChageComplete
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(282, 253);
            this.Controls.Add(this.suc);
            this.Name = "ChageComplete";
            this.Text = "ChageComplete";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label suc;
    }
}