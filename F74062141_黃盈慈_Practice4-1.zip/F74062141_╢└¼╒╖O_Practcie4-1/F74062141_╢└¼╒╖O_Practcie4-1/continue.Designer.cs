﻿namespace F74062141_黃盈慈_Practcie4_1
{
    partial class @continue
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mu = new System.Windows.Forms.Button();
            this.ct = new System.Windows.Forms.Button();
            this.so = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // mu
            // 
            this.mu.Location = new System.Drawing.Point(169, 25);
            this.mu.Name = "mu";
            this.mu.Size = new System.Drawing.Size(113, 36);
            this.mu.TabIndex = 1;
            this.mu.Text = "back to menu";
            this.mu.UseVisualStyleBackColor = true;
            this.mu.Click += new System.EventHandler(this.mu_Click);
            // 
            // ct
            // 
            this.ct.Location = new System.Drawing.Point(36, 25);
            this.ct.Name = "ct";
            this.ct.Size = new System.Drawing.Size(98, 36);
            this.ct.TabIndex = 2;
            this.ct.Text = "continue";
            this.ct.UseVisualStyleBackColor = true;
            this.ct.Click += new System.EventHandler(this.ct_Click);
            // 
            // so
            // 
            this.so.Location = new System.Drawing.Point(311, 25);
            this.so.Name = "so";
            this.so.Size = new System.Drawing.Size(98, 36);
            this.so.TabIndex = 3;
            this.so.Text = "sign out";
            this.so.UseVisualStyleBackColor = true;
            this.so.Click += new System.EventHandler(this.so_Click);
            // 
            // @continue
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(474, 94);
            this.Controls.Add(this.so);
            this.Controls.Add(this.ct);
            this.Controls.Add(this.mu);
            this.Name = "@continue";
            this.Text = "@continue";
            this.Load += new System.EventHandler(this.continue_Load);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button mu;
        private System.Windows.Forms.Button ct;
        private System.Windows.Forms.Button so;
    }
}