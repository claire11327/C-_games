﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace F74062141_黃盈慈_Practcie4_1
{
    public partial class @continue : Form
    {
        public @continue()
        {
            InitializeComponent();
        }
        public  int st = 0;
        private void continue_Load(object sender, EventArgs e)
        {
        }

        private void ct_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void mu_Click(object sender, EventArgs e)
        {
            st = 1;
            this.Close();
        }

        private void so_Click(object sender, EventArgs e)
        {
            st = 2;
            this.Close();
        }
    }
}
