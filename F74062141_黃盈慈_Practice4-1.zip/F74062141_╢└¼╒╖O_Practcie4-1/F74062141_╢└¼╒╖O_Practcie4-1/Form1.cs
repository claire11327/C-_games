﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace F74062141_黃盈慈_Practcie4_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int initial = 10000;
        string psd = "000000";
        bool w_s;
        List<int> hismon = new List<int>();
        List<bool> hisws = new List<bool>();
        int tr;



        private void Form1_Load(object sender, EventArgs e)
        {
            passwd.PasswordChar = '*';
            passwd.MaxLength = 12;
            //passwd.minlength= 6;


            message.Visible = false;


            selectsv.Visible = false;
            withdraw.Visible = false;
            save.Visible = false;
            last.Visible = false;
            history.Visible = false;
            menu.Visible = false;
            changepasswd.Visible = false;
            oldpsd.Visible = false;
            newpsd.Visible = false;
            check.Visible = false;
            sure.Visible = false;
            signout.Visible = false;

            w_s_mon.Visible = false;
            money.Visible = false;
            NTD.Visible = false;
            USD.Visible = false;

            lastmon.Visible = false;
            his.Visible = false;
            label1.Visible = false;

        }
        private void sign_in(object sender, EventArgs e)
        {
            if (passwd.Text == psd)
            {
                passwd.Visible = false;
                signbtn.Visible = false;
                signindex1.Visible = false;
                signindex2.Visible = false;
                message.Visible = false;


                selectsv.Visible = true;
                withdraw.Visible = true;
                save.Visible = true;
                last.Visible = true;
                history.Visible = true;
                signout.Visible = true;
                changepasswd.Visible = true;

                menu.Visible = false;


            }
            else
            {
                message.Visible = true;
                message.Text = "密碼錯誤";
            }
            passwd.Clear();
        }

        private void sign_out(object sender, EventArgs e)
        {
            passwd.Visible = true;
            signbtn.Visible = true;
            signindex1.Visible = true;
            signindex2.Visible = true;
            passwd.Text = "";
            message.Visible = false;

            selectsv.Visible = false;
            withdraw.Visible = false;
            save.Visible = false;
            last.Visible = false;
            history.Visible = false;
            menu.Visible = false;
            changepasswd.Visible = false;
            signout.Visible = false;

            w_s_mon.Visible = false;
            money.Visible = false;
            NTD.Visible = false;
            USD.Visible = false;

            his.Visible = false;
            lastmon.Visible = false;
            oldpsd.Visible = false;
            newpsd.Visible = false;
            check.Visible = false;
            sure.Visible = false;

        }

        private void withdrawmon(object sender, EventArgs e)
        {
            selectsv.Visible = false;
            withdraw.Visible = false;
            save.Visible = false;
            last.Visible = false;
            history.Visible = false;
            changepasswd.Visible = false;


            w_s = true;
            w_s_mon.Visible = true;
            money.Visible = true;
            NTD.Visible = true;
            USD.Visible = true;
            menu.Visible = true;

            w_s_mon.Text = "請輸入提款金額 :";

        }

        private void savemon(object sender, EventArgs e)
        {
            selectsv.Visible = false;
            withdraw.Visible = false;
            save.Visible = false;
            last.Visible = false;
            history.Visible = false;
            changepasswd.Visible = false;

            w_s_mon.Visible = true;
            money.Visible = true;
            NTD.Visible = true;
            USD.Visible = true;
            menu.Visible = true;

            w_s_mon.Text = "請輸入存款金額 :";
            w_s = false;

        }

        private void NTD_Click(object sender, EventArgs e)
        {
            if(!int.TryParse(money.Text,out tr))
            {
            }
            else
            {
                int withdraw = int.Parse(money.Text);
                bool amtmon = true;
                if (w_s)
                {
                    if (initial < withdraw)
                    {
                        lastmon.Visible = true;
                        lastmon.Text = "餘額不足\r\n謝謝您的惠顧，歡迎下次再來";
                        amtmon = false;


                    }
                    initial -= withdraw;
                }
                else
                {
                    initial += withdraw;
                }
                if (amtmon)
                {
                    label1.Text = initial.ToString();
                    money.Text = "";
                    hismon.Add(withdraw);
                    hisws.Add(w_s);
                    withdraw = 0;
                    sign_out(sender, e);/*
                    @continue win_cont = new @continue();
                    win_cont.Show();
                    switch (win_cont.st)
                    {
                        case 0:
                            break;
                        case 1:
                            menu_Click(sender, e);
                            break;
                        case 2:
                            sign_out(sender, e);
                            break;
                    }*/
                }
                else
                {
                    w_s_mon.Visible = false;
                    money.Visible = false;
                    NTD.Visible = false;
                    USD.Visible = false;
                }
            }
            
        }

        private void USD_Click(object sender, EventArgs e)
        {
            int withdraw = int.Parse(money.Text);
            bool amtmon = true;
            if (w_s){
                if (initial < 30 * withdraw)
                {
                    lastmon.Visible = true;
                    lastmon.Text = "餘額不足\r\n謝謝您的惠顧，歡迎下次再來";
                    amtmon = false;

                }
                else
                    initial -= 30*withdraw;
            }
            else{
                initial += 30 * withdraw;
            }
            if (amtmon) {
                label1.Text = initial.ToString();
                money.Text = "";
                hismon.Add(withdraw * 30);
                hisws.Add(w_s);
                withdraw = 0;
                sign_out(sender, e);
            }
            else
            {
                w_s_mon.Visible = false;
                money.Visible = false;
                NTD.Visible = false;
                USD.Visible = false;
            }

        }

        

        private void last_Click(object sender, EventArgs e)
        {
            selectsv.Visible = false;
            withdraw.Visible = false;
            save.Visible = false;
            last.Visible = false;
            history.Visible = false;
            changepasswd.Visible = false;

            menu.Visible = true;

            lastmon.Visible = true;
            string b = initial.ToString();
            lastmon.Text = "餘額剩下 : " + b + "NTD\r\n謝謝您的惠顧，歡迎下次再來";
        }

        private void history_Click(object sender, EventArgs e)
        {
            selectsv.Visible = false;
            withdraw.Visible = false;
            save.Visible = false;
            last.Visible = false;
            history.Visible = false;
            changepasswd.Visible = false;

            menu.Visible = true;


            his.Visible = true;
            int i = 0;
            string hisall = "[初始] 10000 NTD \r\n";

            foreach (int mydata in hismon)
            {   
                string wsdata;
                string mondata = mydata.ToString();
                if (hisws[i]) { wsdata = "提款"; }
                else { wsdata = "存款"; }
                hisall += "[ " + wsdata + " ] " + mondata + " NTD\r\n";
            }
            his.Text = hisall;
            
            
        }
        

        private void menu_Click(object sender, EventArgs e)
        {
            passwd.Visible = false;
            signbtn.Visible = false;
            signindex1.Visible = false;
            signindex2.Visible = false;

            selectsv.Visible = true;
            withdraw.Visible = true;
            save.Visible = true;
            last.Visible = true;
            history.Visible = true;
            changepasswd.Visible = true;
            signout.Visible = true;
            menu.Visible = false;

            w_s_mon.Visible = false;
            money.Visible = false;
            NTD.Visible = false;
            USD.Visible = false;

            lastmon.Visible = false;
            his.Visible = false;
            oldpsd.Visible = false;
            newpsd.Visible = false;
            check.Visible = false;
            sure.Visible = false;
            label1.Visible = false;
        }

        private void changepasswd_Click(object sender, EventArgs e)
        {
            selectsv.Visible = false;
            withdraw.Visible = false;
            save.Visible = false;
            last.Visible = false;
            history.Visible = false;
            changepasswd.Visible = false;

            oldpsd.Visible = true;
            newpsd.Visible = true;
            check.Visible = true;
            sure.Visible = true;
            menu.Visible = true;


        }


        private void sure_Click(object sender, EventArgs e)
        {
            if(newpsd.Text == check.Text && oldpsd.Text == psd)
            {
                oldpsd.Visible = false;
                newpsd.Visible = false;
                check.Visible = false;
                sure.Visible = false;
                psd = newpsd.Text;
                ChageComplete com = new ChageComplete();
                com.Show();
                sign_out(null,null);
            }
            else
            {
                message.Visible = true;
                message.Text = "舊密碼錯誤或新密碼確認錯誤";
            }
            oldpsd.Text = "";
            newpsd.Text = "";
            check.Text = "";

        }

        

        private void oldpsd_MouseClick(object sender, MouseEventArgs e)
        {
            oldpsd.Text = "";          
            
        }

        private void newpsd_MouseClick(object sender, MouseEventArgs e)
        {
            newpsd.Text = "";
            
        }

        private void check_MouseClick(object sender, MouseEventArgs e)
        {
            check.Text = "";
        }

        private void check_TextChanged(object sender, EventArgs e)
        {

            check.PasswordChar = '*';
        }

        private void newpsd_TextChanged(object sender, EventArgs e)
        {
            newpsd.PasswordChar = '*';
        }

        private void oldpsd_TextChanged(object sender, EventArgs e)
        {
            oldpsd.PasswordChar = '*';
        }
    }
}
