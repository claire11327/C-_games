﻿namespace @continue
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.cont = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cont
            // 
            this.cont.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.cont.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.cont.Location = new System.Drawing.Point(105, 33);
            this.cont.Name = "cont";
            this.cont.Size = new System.Drawing.Size(104, 34);
            this.cont.TabIndex = 0;
            this.cont.Text = "continue?";
            this.cont.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(317, 99);
            this.Controls.Add(this.cont);
            this.Name = "Form1";
            this.Text = "Continue";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button cont;
    }
}

