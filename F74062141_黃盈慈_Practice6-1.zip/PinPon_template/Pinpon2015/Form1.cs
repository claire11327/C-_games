﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pingpon20215
{
    public partial class Form1 : Form
    {
        private Random rand;

        int Vx, Vy;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            rand = new Random();

            init();

        }
        
        // 初始化各項變數
        private void init()
        {
            /* your code here */
            lblNotification.Visible = true;
            ball.Location = new Point(rand.Next(0, this.ClientSize.Width-ball.Width), rand.Next(NPC.Bottom,board.Top-ball.Height));
            Vx = 5;
            Vy = 5;
        }

        //球的移動控制
        private void timer1_Tick(object sender, EventArgs e)
        {
            /*** 處理球的碰撞 ***/
            /* your code here */ //X方向移動
            ball.Left += Vx;
            /* your code here */ //Y方向移動
            ball.Top += Vy;

            /* your code here */ //處理左邊界碰撞
            if (ball.Left < 0)
                Vx = Math.Abs(Vx);
            /* your code here */ //處理右邊界碰撞
            if (ball.Right >= this.ClientSize.Width)
                Vx = (-1) * Math.Abs(Vx);

            int center = (ball.Left + ball.Right) / 2; //球的中點X座標

            if (ball.Top <= NPC.Bottom) //高於NPC高度時(可能碰撞板子)
            {
                if (center >= NPC.Left && center <= NPC.Right) //球在球拍寬度範圍內
                {
                    double F = ((double)center - (double)NPC.Left) / (double)NPC.Width; // 以擊球點計算擊球力道
                    if (Vx < 0) { F = (1.0 - F); } // 力道方向調整
                    F = F + 0.5; // 力道大小修正
                    /* your code here */ // 施加力道
                    /* your code here */ //反彈
                    Vy = Math.Abs(Vy);

                }
                else // 沒接到
                {
                    /* your code here */ // 結束球的運動
                    timer1.Enabled = false;
                    /* your code here */ //顯示訊息結束遊戲
                    MessageBox.Show("You Win");
                    /* your code here */ // 重新開始
                    init();

                }
            }

            if (ball.Bottom >= board.Top) //低於擊球板高度時(可能碰撞板子)
            {
                if (center >= board.Left && center <= board.Right) //球在球拍寬度範圍內
                {
                    double F = ((double)center - (double)board.Left) / (double)board.Width; // 以擊球點計算擊球力道
                    if (Vx < 0) { F = (1.0 - F); } // 力道方向調整
                    F = F + 0.5; // 力道大小修正
                    /* your code here */ // 施加力道
                    /* your code here */ //反彈
                    Vy = (-1) * Math.Abs(Vy);
                }
                else // 沒接到
                {
                    /* your code here */ //結束球的運動
                    timer1.Enabled = false;
                    /* your code here */ //顯示訊息結束遊戲
                    MessageBox.Show("Game Over");
                    /* your code here */ // 重新開始
                    init();
                }
            }

            /*** 處理NPC的移動 ***/
            int NPCmid = (NPC.Right + NPC.Left) / 2;

            if (center < NPCmid) // 球在左邊向左移
            {
                /* your code here */
                NPC.Left -= 5;
            }
            else if (center > NPCmid) // 球在右邊向右移
            {
                /* your code here */
                NPC.Left += 5;
            }
        }

        int mdx; //球拍拖曳X起點

        //開始拖曳
        private void P_MouseDown(object sender, MouseEventArgs e)
        {
            if(timer1.Enabled == false) // 如果遊戲還沒開始
            {
                /* your code here */
                timer1.Enabled = true;
                lblNotification.Visible = false;
            }
            /* your code here */ //拖曳X起點
            mdx = e.X;
            
        }

        //拖曳中
        private void P_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left) //左鍵按下(拖曳)狀態
            {
                board.Left +=  e.X - mdx; /* your code here */;
            }
        }
    }
}
