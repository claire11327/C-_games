﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class hero
    {
        public int hero_wpn;
        public string[] herowpimg;
        public string[] heroimg = new string[]
                            {
                                "  *****    ",
                                "  *   *    ",
                                "  ***** *  ",
                                "    *  *  *",
                                "    * * *  ",
                                "    ***    ",
                                "    *      ",
                                "   * *     ",
                                "  *   *    ",
                                " *     *   ",
                                " *     *   "
                            };
        public string[] monimg = new string[]
                        {
                                "           ",
                                "           ",
                                "      *    ",
                                "     *     ",
                                "     *     ",
                                "   *****   ",
                                " *** * *** ",
                                "***********",
                                " ********* ",
                                "           ",
                                "           "
                        };
        public string[] sword =
                        {
                                "     *     ",
                                "   *   *   ",
                                "   *   *   ",
                                "   *   *   ",
                                "   *   *   ",
                                "   *   *   ",
                                " ********* ",
                                " ********* ",
                                "    ***    ",
                                "    ***    ",
                                "           "
                            };
        public string[] hammer = new string[]
                        {
                                "***********",
                                "***********",
                                "***********",
                                "    ***    ",
                                "    ***    ",
                                "    ***    ",
                                "    ***    ",
                                "    ***    ",
                                "    ***    ",
                                "    ***    ",
                                "           "
                        };
        public string[] spear = new string[]
                        {
                                "     *     ",
                                "    ***    ",
                                "   *****   ",
                                "  *******  ",
                                "     *     ",
                                "     *     ",
                                "     *     ",
                                "     *     ",
                                "     *     ",
                                "     *     ",
                                "           "
                        };

        
}
}
