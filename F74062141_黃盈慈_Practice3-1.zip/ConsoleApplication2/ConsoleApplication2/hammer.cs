﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class hammer
    {
        public Random ranObj = new Random();
        public string ans;
        //switch (ranno)
        public string moro()
        {
            int ran = ranObj.Next(0, 4);
            switch (ran)
            {
                case 0:
                    ans = "Pa";
                    break;
                case 1:
                    ans = "st";
                    break;
                case 2:
                    ans = "st";
                    break;
                case 3:
                    ans = "st";
                    break;
                case 4:
                    ans = "sc";
                    break;
            }
            return ans;
        }
    }
}
