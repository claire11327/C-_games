﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            int hero_wp, mon_wp, win = 0, lose = 0;
            string herowpstring, hmoro ="", mmoro = "";
            sword sw = new sword();
            spear sp = new spear();
            hammer ha = new hammer();
            Random ranObj = new Random();
            string[] heroimg = new string[]
                            {
                                "  *****    ",
                                "  *   *    ",
                                "  ***** *  ",
                                "    *  *  *",
                                "    * * *  ",
                                "    ***    ",
                                "    *      ",
                                "   * *     ",
                                "  *   *    ",
                                " *     *   ",
                                " *     *   "
                            };
            string[] monimg = new string[]
                            {
                                "           ",
                                "           ",
                                "      *    ",
                                "     *     ",
                                "     *     ",
                                "   *****   ",
                                " *** * *** ",
                                "***********",
                                " ********* ",
                                "           ",
                                "           "
                            };
            string[] sword =
                            {
                                "     *     ",
                                "   *   *   ",
                                "   *   *   ",
                                "   *   *   ",
                                "   *   *   ",
                                "   *   *   ",
                                " ********* ",
                                " ********* ",
                                "    ***    ",
                                "    ***    ",
                                "           "
                            };
            string[] hammer = new string[]
                            {
                                "***********",
                                "***********",
                                "***********",
                                "    ***    ",
                                "    ***    ",
                                "    ***    ",
                                "    ***    ",
                                "    ***    ",
                                "    ***    ",
                                "    ***    ",
                                "           "
                            };
            string[] spear = new string[]
                            {
                                "     *     ",
                                "    ***    ",
                                "   *****   ",
                                "  *******  ",
                                "     *     ",
                                "     *     ",
                                "     *     ",
                                "     *     ",
                                "     *     ",
                                "     *     ",
                                "           "
                            };
            
            Console.WriteLine("請輸入勇者的武器");
            Console.WriteLine("(武器的種類共三種,0~2為種類,3為隨機)");
            Console.WriteLine("直接輸入enter為離開");
            herowpstring = Console.ReadLine();
            
            while (!string.IsNullOrEmpty(herowpstring)) {

                hero_wp = int.Parse(herowpstring);
                Console.WriteLine("請輸入萌絲塔的武器");
                mon_wp = int.Parse(Console.ReadLine());
                if (hero_wp == 3)
                {
                    hero_wp = ranObj.Next(0, 3);
                }
                if (mon_wp == 3)
                {
                    mon_wp = ranObj.Next(0, 3);
                }
                

                while (lose == 0)
                {
                    switch (hero_wp)
                    {
                        case 0:
                            hmoro = sw.moro();
                            switch (mon_wp)
                            {
                                case 0:
                                    mmoro = sw.moro();
                                    for (int i = 0; i < 11; i++)
                                    {
                                        Console.WriteLine("{0}     {1}     {2}     {3}", heroimg[i], sword[i], sword[i], monimg[i]);
                                    }

                                    break;
                                case 1:
                                    mmoro = ha.moro();
                                    for (int i = 0; i < 11; i++)
                                    {
                                        Console.WriteLine("{0}     {1}     {2}     {3}", heroimg[i], sword[i], hammer[i], monimg[i]);
                                    }
                                    break;
                                case 2:
                                    mmoro = sp.moro();
                                    for (int i = 0; i < 11; i++)
                                    {
                                        Console.WriteLine("{0}     {1}     {2}     {3}", heroimg[i], sword[i], spear[i], monimg[i]);
                                    }
                                    break;
                            }
                            break;
                        case 1:
                            hmoro = ha.moro();
                            switch (mon_wp)
                            {
                                case 0:
                                    mmoro = sw.moro();
                                    for (int i = 0; i < 11; i++)
                                    {
                                        Console.WriteLine("{0}     {1}     {2}     {3}", heroimg[i], hammer[i], sword[i], monimg[i]);
                                    }
                                    break;
                                case 1:
                                    mmoro = ha.moro();
                                    for (int i = 0; i < 11; i++)
                                    {
                                        Console.WriteLine("{0}     {1}     {2}     {3}", heroimg[i], hammer[i], hammer[i], monimg[i]);
                                    }
                                    break;
                                case 2:
                                    mmoro = sp.moro();
                                    for (int i = 0; i < 11; i++)
                                    {
                                        Console.WriteLine("{0}     {1}     {2}     {3}", heroimg[i], hammer[i], spear[i], monimg[i]);
                                    }
                                    break;
                            }
                            break;
                        case 2:
                            hmoro = sp.moro();
                            switch (mon_wp)
                            {
                                case 0:
                                    mmoro = sw.moro();
                                    for (int i = 0; i < 11; i++)
                                    {
                                        Console.WriteLine("{0}     {1}     {2}     {3}", heroimg[i], spear[i], sword[i], monimg[i]);
                                    }
                                    break;
                                case 1:
                                    mmoro = ha.moro();
                                    for (int i = 0; i < 11; i++)
                                    {
                                        Console.WriteLine("{0}     {1}     {2}     {3}", heroimg[i], spear[i], hammer[i], monimg[i]);
                                    }
                                    break;
                                case 2:
                                    mmoro = sp.moro();
                                    for (int i = 0; i < 11; i++)
                                    {
                                        Console.WriteLine("{0}     {1}     {2}     {3}", heroimg[i], spear[i], spear[i], monimg[i]);
                                    }
                                    break;
                            }
                            break;
                        default:
                            break;
                    }
                    switch (hmoro)
                    {
                        case "Pa":
                            switch (mmoro)
                            {
                                case "Pa":
                                    Console.WriteLine("All Might 出布　monster　出布");
                                    Console.WriteLine("All Might　平局");
                                    break;
                                case "st":
                                    Console.WriteLine("All Might 出布　monster　出石頭");
                                    Console.WriteLine("All Might　勝利");
                                    win++;
                                    break;
                                case "sc":
                                    Console.WriteLine("All Might 出布　monster　出剪刀");
                                    Console.WriteLine("All Might　失敗");
                                    lose++;
                                    break;
                            }
                            break;
                        case "st":
                            switch (mmoro)
                            {
                                case "Pa":
                                    Console.WriteLine("All Might 出石頭　monster　出布");
                                    Console.WriteLine("All Might　失敗");
                                    lose++;
                                    break;
                                case "st":
                                    Console.WriteLine("All Might 出石頭　monster　出石頭");
                                    Console.WriteLine("All Might　平局");
                                    break;
                                case "sc":
                                    Console.WriteLine("All Might 出石頭　monster　出剪刀");
                                    Console.WriteLine("All Might　勝利");
                                    win++;
                                    break;
                            }
                            break;
                        case "sc":
                            switch (mmoro)
                            {
                                case "Pa":
                                    Console.WriteLine("All Might 出剪刀　monster　出布");
                                    win++;
                                    break;
                                case "st":
                                    Console.WriteLine("All Might 出剪刀　monster　出石頭");
                                    Console.WriteLine("All Might　失敗");
                                    lose++;
                                    break;
                                case "sc":
                                    Console.WriteLine("All Might 出剪刀　monster　出剪刀");
                                    Console.WriteLine("All Might　平局");
                                    break;
                            }
                            break;
                    }
                    mon_wp = ranObj.Next(0, 3);
                }

                


                Console.WriteLine("All Might的勝利場數為：{0}",win);
                Console.WriteLine();

                lose = 0;
                win = 0;

                Console.WriteLine("請輸入勇者的武器");
                Console.WriteLine("(武器的種類共三種,0~2為種類,3為隨機)");
                Console.WriteLine("直接輸入enter為離開");
                herowpstring = Console.ReadLine();
            }

       
            Console.Read();
        
        }
    }
}
